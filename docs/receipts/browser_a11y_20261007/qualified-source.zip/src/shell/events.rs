// Copyright 2026 Mark Alan Boykin
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0

//! The winit handler: platform events in, delivered input and redraws out.
//!
//! Thin on purpose. Each arm maps a platform event onto the shared delivery
//! seams (`on_key`, `deliver_press`, `deliver_wheel`) that the scenario runner
//! also drives, so one description runs through two runners.

use winit::application::ApplicationHandler;
use winit::event::{ElementState, Ime, MouseScrollDelta, StartCause, WindowEvent};
use winit::event_loop::{ActiveEventLoop, ControlFlow};
use winit::window::WindowId;

use std::sync::Arc;

use fetch::FetchUpdate;
use genet_winit_host::SurfaceHost;
use mere::canvas::WHEEL_PAN_SCALE;
use netrender::NetrenderOptions;
use winit::dpi::PhysicalSize;
use winit::window::Window;

use crate::action::Action;
use crate::browse;

use super::Shell;

impl ApplicationHandler for Shell {
    fn new_events(&mut self, _event_loop: &ActiveEventLoop, _cause: StartCause) {
        self.observe_physics_display_rate(false);
        #[cfg(all(feature = "servo", windows))]
        if let Err(error) = super::servo::pump() {
            tracing::warn!(%error, "Servo process event pump failed");
        }
        // Native COM calls can consume/coalesce Win32 paint requests during
        // input delivery. A deadline wake requests paint outside WM_PAINT so
        // captured browser mailboxes and self-drive cannot lose their clock.
        // Replace this fallback when the engines expose a host wake callback.
        let active = !self.surface_producers.is_empty() || self.shared_scenario.is_some();
        if self.surface_poll_clock.poll_due(active, std::time::Instant::now()) {
            self.request_redraw();
        }
    }

    fn about_to_wait(&mut self, event_loop: &ActiveEventLoop) {
        let effects = self.app.tick(crate::denizen::now_ms());
        self.run_effects(effects);
        self.pump_redshank();
        #[cfg(all(feature = "servo", windows))]
        if let Err(error) = super::servo::pump() {
            tracing::warn!(%error, "Servo process event pump failed");
        }
        // Live captured surfaces require a clock independent of paint delivery.
        // Otherwise a minute supplies the idle W4 schedule clock.
        let active = !self.surface_producers.is_empty() || self.shared_scenario.is_some();
        let now = std::time::Instant::now();
        let deadline = self.surface_poll_clock.deadline(active, now)
            .unwrap_or_else(|| now + std::time::Duration::from_secs(60));
        event_loop.set_control_flow(ControlFlow::WaitUntil(deadline));
    }

    fn exiting(&mut self, _event_loop: &ActiveEventLoop) {
        #[cfg(all(feature = "servo", windows))]
        {
            self.clear_surface_content();
            if let Err(error) = super::servo::shutdown() {
                tracing::warn!(%error, "Servo process shutdown failed");
            }
        }
        // The trail memory buffers traversals between lifecycle edges, and a
        // normal quit is one: flush-and-release with a bounded ack so the
        // last session's tail survives exit. (The bin needs no exit hook —
        // it persists each record as it arrives.)
        let (ack_tx, ack_rx) = std::sync::mpsc::sync_channel(1);
        self.trail_handle
            .command(crate::trail_memory::TrailCommand::Release(ack_tx));
        if ack_rx
            .recv_timeout(std::time::Duration::from_millis(1500))
            .is_err()
        {
            tracing::warn!("trail memory release ack timed out at exit");
        }
    }

    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let attributes = Window::default_attributes()
            .with_title("Turnstone")
            .with_inner_size(PhysicalSize::new(self.width, self.height))
            // Hidden at creation on purpose: the AccessKit adapter must be
            // installed before the window is first shown, and a window that
            // flashes unbridged is a window a screen reader met too early.
            .with_visible(false);
        let window = Arc::new(
            event_loop
                .create_window(attributes)
                .expect("failed to create the turnstone window"),
        );
        self.a11y_adapter = Some(crate::shell::a11y_bridge::install(
            event_loop,
            &window,
            self.a11y_shared.clone(),
            self.a11y_actions.clone(),
            self.proxy.clone(),
            self.a11y_reactivation.clone(),
        ));
        window.set_visible(true);
        let size = window.inner_size();
        self.width = size.width.max(1);
        self.height = size.height.max(1);
        self.app.graph_runtimes.resize(self.width, self.height);
        self.app.graph_runtimes.set_physics_display_rate(
            window
                .current_monitor()
                .and_then(|monitor| monitor.refresh_rate_millihertz()),
        );
        self.physics_display_rate_last_observed = Some(std::time::Instant::now());
        self.app.viewport = (self.width as f32, self.height as f32);
        self.app.reflow_omnibar();
        // Frame the content, not the origin: a restored session's persisted
        // positions can have settled anywhere in world space, and a camera
        // centered on the origin would then show empty ground.
        self.app.graph_runtimes.fit_to_content();

        let options = NetrenderOptions {
            tile_cache_size: Some(64),
            enable_vello: true,
            // Windows browser producers export D3D12 shared textures. The
            // host must use the same API before constructing either producer.
            #[cfg(all(any(feature = "weld", feature = "scry", feature = "servo"), windows))]
            backends: Some(wgpu::Backends::DX12),
            ..Default::default()
        };
        match SurfaceHost::boot(window.clone(), self.width, self.height, options) {
            Ok(host) => self.host = Some(host),
            Err(err) => {
                eprintln!("[turnstone] {err}");
                event_loop.exit();
                return;
            }
        }

        // Restored Weld-pinned nodes are requested before winit gives us a
        // device. Now that the host exists, replay their ordinary spawn effect
        // through the same registry path a live viewer change uses.
        let pending_surface_spawns = std::mem::take(&mut self.pending_surface_spawns);
        for (node, url) in pending_surface_spawns {
            self.run_effects(vec![crate::action::Effect::SpawnContent { node, url }]);
        }

        // Always-offload physics: the simulation runs on an armillary actor
        // thread and wakes this loop through the proxy when a layout snapshot
        // lands, so a heavy settle never blocks compositing or input.
        let proxy = self.proxy.clone();
        let physics_wake: armillary::Wake = Arc::new(move || {
            let _ = proxy.send_event(());
        });
        self.app.graph_runtimes.offload_physics(physics_wake);

        window.request_redraw();
        self.window = Some(window);
    }

    /// An actor woke us through the proxy: a physics layout snapshot or a
    /// completed fetch is waiting. Drain fetches through the spine, then
    /// redraw so `frame()` folds everything in (and chains while settling).
    fn user_event(&mut self, event_loop: &ActiveEventLoop, _event: ()) {
        while let Ok(raw) = self
            .fetch_rx
            .try_recv()
            .or_else(|_| self.nomadnet_rx.try_recv())
        {
            let raw = match raw {
                FetchUpdate::Subresource(outcome) => {
                    let requesters = self.pending_fetches.take_subresources(&outcome.url);
                    if requesters.is_empty() {
                        tracing::warn!(url = %outcome.url, "subresource completion without a pending session; dropped");
                        continue;
                    }
                    match outcome.result {
                        Ok(bytes) => {
                            for node in requesters {
                                if let Some(session) = self.content_sessions.get_mut(&node) {
                                    session.provide_subresource(&outcome.url, &bytes);
                                }
                            }
                        }
                        Err(error) => {
                            tracing::warn!(url = %outcome.url, %error, "content subresource failed");
                        }
                    }
                    continue;
                }
                other => other,
            };
            // The port adapter converts the service's types at the boundary;
            // the app only ever sees the app-owned vocabulary.
            if let Some(update) = browse::update_from_fetch(raw, &mut self.pending_fetches) {
                let effects = self.app.apply_update(update);
                self.run_effects(effects);
            }
        }
        while let Ok(update) = self.bin_rx.try_recv() {
            // The bin actor already speaks the app-owned vocabulary.
            let effects = self.app.apply_update(update);
            self.run_effects(effects);
        }
        while let Ok(update) = self.download_rx.try_recv() {
            let effects = self.app.apply_update(update);
            self.run_effects(effects);
        }
        while let Ok(update) = self.trail_rx.try_recv() {
            // Recall answers (RecallHits / RecallFailed), already app-owned.
            let effects = self.app.apply_update(update);
            self.run_effects(effects);
        }
        while let Ok(update) = self.place_rx.try_recv() {
            // One place answer the app never sees: a prepared dial is a
            // shell-owned thing. The app learns of a refusal as an event and
            // of a visit only as the document that then opens.
            if let crate::action::Update::PlaceDocumentVisit {
                holder_root,
                result,
                ..
            } = update
            {
                self.apply_document_visit(holder_root, result);
                continue;
            }
            let effects = self.app.apply_update(update);
            self.run_effects(effects);
        }
        self.refresh_knot_documents();
        while let Ok(update) = self.micron_submission_rx.try_recv() {
            let effects = self.app.apply_update(update);
            self.run_effects(effects);
        }
        // Any cookie a fetch or a script set since the last drain goes to disk
        // now; the flush is dirty-gated, so a quiet drain writes nothing.
        self.cookie_custody.flush();
        self.drain_surface_web_events();
        self.drain_surface_accessibility();
        // Semantic callbacks publish on their own wake, before any pixel
        // frame acquisition or queued assistive action delivery.
        self.push_a11y_tree();
        self.drain_a11y_actions();
        self.drain_pending_windows(event_loop);
        self.request_redraw();
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        window_id: WindowId,
        event: WindowEvent,
    ) {
        if let (Some(adapter), Some(window)) = (self.a11y_adapter.as_mut(), self.window.as_ref())
            && window.id() == window_id
        {
            tracing::debug!(target: "turnstone::selfdrive", redraw = matches!(event, WindowEvent::RedrawRequested), "begin accessibility event delivery");
            adapter.process_event(window, &event);
            tracing::debug!(target: "turnstone::selfdrive", "finished accessibility event delivery");
        }
        if self.window.as_ref().map(|w| w.id()) != Some(window_id) {
            // A lens window's event (rung 7): canvas gestures through the
            // lens's own camera; everything else is the primary's.
            if self.lens_windows.contains_key(&window_id) {
                self.lens_event(window_id, event);
                self.drain_pending_windows(event_loop);
            }
            return;
        }
        match event {
            WindowEvent::Moved(_) | WindowEvent::ScaleFactorChanged { .. } => {
                self.observe_physics_display_rate(true);
            },
            WindowEvent::CloseRequested => {
                self.act(Action::SaveSession);
                self.release_place_worker();
                event_loop.exit();
            }
            // A dropped file lands at the last tracked cursor position (winit
            // carries no position on the drop event itself; mid-drag hover
            // updates CursorMoved on the platforms that report it).
            WindowEvent::DroppedFile(path) => {
                let (x, y) = self.cursor;
                self.drop_file(x, y, &path);
            }
            WindowEvent::HoveredFile(path) => {
                let (x, y) = self.cursor;
                self.hover_file(x, y, &path);
            }
            WindowEvent::HoveredFileCancelled => self.cancel_host_file_drag(),
            WindowEvent::Resized(size) => {
                self.width = size.width.max(1);
                self.height = size.height.max(1);
                if let Some(host) = self.host.as_mut() {
                    host.resize(self.width, self.height);
                }
                self.app.graph_runtimes.resize(self.width, self.height);
                self.app.viewport = (self.width as f32, self.height as f32);
                self.app.reflow_omnibar();
                self.request_redraw();
            }
            // Continuous gestures map onto the canvas's semantic input methods
            // directly (they are already the right typed vocabulary); Actions
            // are the app-intent tier above. (Architecture plan, the spine.)
            WindowEvent::ModifiersChanged(mods) => {
                self.ctrl = mods.state().control_key();
                self.alt = mods.state().alt_key();
                self.shift = mods.state().shift_key();
                self.app.graph_runtimes.set_ctrl(mods.state().control_key());
                self.app.graph_runtimes.set_alt(mods.state().alt_key());
            }
            WindowEvent::CursorMoved { position, .. } => {
                self.cursor = (position.x as f32, position.y as f32);
                self.deliver_move(self.cursor.0, self.cursor.1);
                self.deliver_hover(self.cursor.0, self.cursor.1);
                self.update_host_file_drag(self.cursor.0, self.cursor.1);
                let graph_redraw = self
                    .surface_plan()
                    .into_iter()
                    .find(|surface| surface.rect.contains(self.cursor.0, self.cursor.1))
                    .and_then(|surface| match surface.kind {
                        crate::surface::SurfaceKind::Graph(pane) => {
                            Some(self.app.graph_pane_cursor_moved(
                                pane,
                                self.cursor.0 - surface.rect.x,
                                self.cursor.1 - surface.rect.y,
                            ))
                        }
                        _ => None,
                    })
                    .unwrap_or(false);
                if graph_redraw {
                    self.request_redraw();
                }
            }
            WindowEvent::CursorLeft { .. } => self.reset_surface_cursor(),
            WindowEvent::MouseWheel { delta, .. } => {
                // Lines-to-pixels: the canvas pan scale doubles as the content
                // scroll scale (both want ~40px per wheel line).
                let (dx, dy) = match delta {
                    MouseScrollDelta::LineDelta(x, y) => (x * WHEEL_PAN_SCALE, y * WHEEL_PAN_SCALE),
                    MouseScrollDelta::PixelDelta(p) => (p.x as f32, p.y as f32),
                };
                let (cx, cy) = self.cursor;
                self.deliver_wheel(cx, cy, dx, dy);
            }
            WindowEvent::MouseInput { state, button, .. } => {
                let (x, y) = self.cursor;
                match state {
                    ElementState::Pressed => self.deliver_press(x, y, button),
                    ElementState::Released => self.deliver_release(x, y, button),
                }
            }
            WindowEvent::Touch(touch) => self.deliver_touch(touch),
            WindowEvent::KeyboardInput { event, .. } => {
                if !self.deliver_surface_key(
                    &event.logical_key,
                    event.state == ElementState::Pressed,
                    event.text.as_deref(),
                ) && event.state == ElementState::Pressed
                {
                    self.on_key(&event.logical_key);
                }
            }
            // IME composition. Preedit is ephemeral by the gesture law — it
            // rides directly on state and only the commit lowers to an
            // Action (`OmnibarInsert`, the same path a future paste takes).
            WindowEvent::Ime(ime) => {
                if self.app.user_agent_decision.is_open() {
                    if self.app.user_agent_decision.accepts_text()
                        && let Ime::Commit(s) = ime
                    {
                        self.act(Action::InsertAuthentication(s));
                    }
                    return;
                }
                if self.app.document_find.open {
                    if let Ime::Commit(s) = ime {
                        self.act(Action::InsertDocumentFind(s));
                    }
                    return;
                }
                if !self.app.omnibar.open && self.deliver_contributed_ime(&ime) {
                    self.request_redraw();
                    return;
                }
                if !self.app.omnibar.open && self.deliver_knot_ime(&ime) {
                    self.request_redraw();
                    return;
                }
                if !self.app.omnibar.open {
                    return;
                }
                match ime {
                    Ime::Commit(s) => {
                        self.app.omnibar.preedit = None;
                        self.act(Action::OmnibarInsert(s));
                    }
                    Ime::Preedit(s, _caret) => {
                        self.app.omnibar.preedit = (!s.is_empty()).then_some(s);
                        self.request_redraw();
                    }
                    Ime::Enabled | Ime::Disabled => {}
                }
            }
            WindowEvent::RedrawRequested => {
                self.observe_physics_display_rate(false);
                tracing::debug!(target: "turnstone::selfdrive", "begin render");
                self.render();
                tracing::debug!(target: "turnstone::selfdrive", "finished render; begin accessibility update");
                self.push_a11y_tree();
                tracing::debug!(target: "turnstone::selfdrive", "finished accessibility update; begin scenario tick");
                self.scenario_pump(event_loop);
                tracing::debug!(target: "turnstone::selfdrive", "finished scenario tick");
            }
            _ => {}
        }
        self.drain_pending_windows(event_loop);
    }
}

impl Shell {
    /// Refresh changes need not move the window or change its scale. Sample
    /// on the existing host cadence, with unchanged rates suppressed by the
    /// runtime pool. No extra event-loop wake is needed while the host is idle.
    fn observe_physics_display_rate(&mut self, force: bool) {
        let Some(window) = self.window.as_ref() else {
            return;
        };
        let now = std::time::Instant::now();
        if !force
            && self.physics_display_rate_last_observed.is_some_and(|last| {
                now.duration_since(last) < std::time::Duration::from_secs(1)
            })
        {
            return;
        }
        self.physics_display_rate_last_observed = Some(now);
        self.app.graph_runtimes.set_physics_display_rate(
            window
                .current_monitor()
                .and_then(|monitor| monitor.refresh_rate_millihertz()),
        );
    }

    /// The Redshank command loop, one turn per event batch: take what the
    /// mounted docks issued, apply it through the app's one listening
    /// authority, then show every dock what the model and runtime now say.
    fn pump_redshank(&mut self) {
        let commands = self.redshank_docks.drain();
        if !commands.is_empty() {
            let effects = self.app.apply_redshank_commands(commands);
            self.run_effects(effects);
        }
        for item in self.redshank_docks.items() {
            let projection = self.app.redshank_projection(&item);
            self.redshank_docks.project(&item, projection);
        }
    }
}
