// Copyright 2026 Mark Alan Boykin
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0

//! The one vocabulary: everything that acts on turnstone lowers to an
//! [`Action`]; everything slow or platform-shaped leaves [`crate::app`] as an
//! [`Effect`] the shell runs through a port; services answer with an
//! [`Update`] drained on wake. Settings, automation, scenarios, scripting,
//! and remote control all speak this vocabulary, so no lane grows a second
//! execution model (the architecture plan's doctrine 2 — the meerkat
//! `command_drain` lesson).
//!
//! Two deliberate boundaries:
//!
//! * **The gesture law.** Ephemeral interaction may bypass Action: the
//!   canvas's semantic input methods (`pointer_down`, `cursor_moved`,
//!   `wheel`, ...) are already a typed vocabulary at the right granularity,
//!   and the shell maps raw input onto them directly. Durable or externally
//!   observable semantic change may not bypass — a gesture that ends in one
//!   surfaces a semantic event at gesture end. `Action` is the app-intent
//!   tier (navigate, reseed, flip a view mode), the tier automation and
//!   commands speak.
//! * **Port-agnostic messages.** This module never imports a service crate:
//!   [`Update`] carries app-owned types, and each port's adapter
//!   ([`crate::browse`] for the fetch actor) converts the service's concrete
//!   types at the boundary. The universal vocabulary must not depend on one
//!   port implementation.

use crate::panes::{PaneKindId, PaneSource};

/// A short-lived secret whose debug representation never contains the value.
#[derive(Clone, Default, PartialEq, Eq)]
pub struct SensitiveString(String);

impl SensitiveString {
    pub fn new(value: String) -> Self {
        Self(value)
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }

    pub fn push_str(&mut self, value: &str) {
        self.0.push_str(value);
    }

    pub fn pop(&mut self) -> Option<char> {
        self.0.pop()
    }
}

impl std::fmt::Debug for SensitiveString {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("[redacted]")
    }
}

/// Which window's frisket space a tree op targets: the primary tree or a live
/// lens's. Pane ids are unique across every space, so a pane-anchored op
/// resolves its own space ([`crate::app::App::space_of`]); only the
/// path-addressed divider drag names its tree explicitly.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SpaceRef {
    Primary,
    /// A lens window's space, by ordinal into `App::lenses`.
    Lens(usize),
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DocumentFindDirection {
    Previous,
    Next,
}

#[derive(Clone, Debug, PartialEq)]
pub struct DocumentFindMatch {
    pub label: String,
    pub role: Option<String>,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct DocumentFindModel {
    /// Authoritative count, including engine-managed matches that do not carry
    /// host-visible structural descriptions.
    pub count: usize,
    pub matches: Vec<DocumentFindMatch>,
    pub current: Option<usize>,
    pub complete: bool,
}

/// Which place artifact a read is expected to hold. The shell parses the
/// bytes into exactly this shape and refuses anything else; a mislabelled
/// file is a refusal, never a guess.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PlaceArtifactKind {
    /// A place card, read to offer a pre-key against its Moot.
    Card,
    /// A published pre-key offer, read to author an invitation for it. The
    /// access it will admit at rides along: the prompt that asked for the
    /// path is what decided it, not the file.
    Prekey {
        access: crate::place::PlaceInviteAccess,
        /// A writer's grant lifetime, or `None` for grants without expiry.
        lifetime_ms: Option<u64>,
    },
    /// An invitation envelope, read to join through it.
    Invite,
}

/// A typed app intent. The shell (keys, later the omnibar / command palette /
/// automation adapters) produces these; [`crate::app::update`] consumes them.
#[derive(Clone, Debug, PartialEq)]
pub enum Action {
    /// Open an address: mint/select its node in the graph and fetch it.
    OpenAddress(String),
    /// Open the submission composer for the focused Titan or Spartan address.
    ComposeFocusedSmolwebSubmission,
    /// Open the focused Micron page's explicit form editor, if it has one.
    ComposeFocusedMicronForm,
    /// Begin a submission from a typed document interaction or explicit target.
    BeginSmolwebSubmission {
        source: Option<uuid::Uuid>,
        target: String,
    },
    /// Replace the composer's body with bytes read from a dropped file.
    SmolwebSubmissionFile {
        name: String,
        bytes: Vec<u8>,
        suggested_mime: String,
    },
    /// A live navigable committed a new top-level resource in an existing
    /// graph member. This grows that member's own navigation lineage; it does
    /// not mint another member merely because its current URL changed.
    ContentNavigationCommitted {
        member: uuid::Uuid,
        url: String,
    },
    /// The active document supplied a title for its existing graph member.
    ContentTitleChanged {
        member: uuid::Uuid,
        title: String,
    },
    /// Capture the focused live document and open its retained find field.
    OpenDocumentFind,
    CloseDocumentFind,
    InsertDocumentFind(String),
    BackspaceDocumentFind,
    StepDocumentFind(DocumentFindDirection),
    /// Step one member's requested page zoom a rung up the ladder. A document
    /// scale: chrome appearance and the canvas camera are untouched. The
    /// member rides along (the `KeepNode` shape) because the palette rows
    /// resolve the focused node while ctrl+wheel resolves the node under the
    /// pointer, and a workbench can tile several live documents at once.
    PageZoomIn {
        member: uuid::Uuid,
    },
    /// Step one member's requested page zoom a rung down.
    PageZoomOut {
        member: uuid::Uuid,
    },
    /// Return one member to the default page scale.
    PageZoomReset {
        member: uuid::Uuid,
    },
    /// Capture this exact live page member. The target is resolved when the
    /// action is offered so a later focus change cannot redirect completion.
    CapturePage {
        member: uuid::Uuid,
    },
    /// Explicitly preserve the current fetched HTML source and its Fleece
    /// annotation. This does not inspect a rendered surface or recall text.
    CaptureSourceDocument {
        member: uuid::Uuid,
    },
    ChoosePermission {
        request: crate::user_agent_decision::UserAgentRequestKey,
        choice: crate::user_agent_decision::PermissionChoice,
    },
    FocusAuthenticationField(crate::user_agent_decision::AuthenticationField),
    InsertAuthentication(String),
    BackspaceAuthentication,
    ToggleAuthenticationMemory,
    SubmitAuthentication {
        request: crate::user_agent_decision::UserAgentRequestKey,
    },
    CancelAuthentication {
        request: crate::user_agent_decision::UserAgentRequestKey,
    },
    /// Step the focused node back through its own content lineage. No-op at
    /// that node's oldest entry.
    NavBack,
    /// Step the focused node forward through its own content lineage.
    NavForward,
    /// Reload the focused node: refetch its enrichment, and respawn its live
    /// content session when it has one.
    Reload,
    /// Stop the focused node's active page request or hosted navigation.
    Stop,
    /// Promote one exact graph member into durable kept state. The member is
    /// captured when the control is offered so a later focus change cannot
    /// redirect the gesture.
    KeepNode {
        member: uuid::Uuid,
    },
    /// Keep the focused node as a feed source and refresh it on this cadence.
    /// The first refresh is immediate; later refreshes use the host clock.
    SubscribeFocusedFeed {
        period: servitor::Period,
    },
    /// Stop scheduled refreshes for the focused source. The node remains kept.
    UnsubscribeFocusedFeed,
    /// Refresh every subscribed source now, subject to the in-flight gate.
    RefreshFeeds,
    /// Clear the unread marker from the focused feed entry.
    MarkFocusedFeedEntryRead,
    /// Set a node's sprite face (a dropped image file, decoded by the shell
    /// into a PNG data-URI — the decode is platform/file work, so it happens
    /// port-side and only the typed result lowers). `hull` is the traced
    /// collider polygon (face-normalized; under 3 points = keep the
    /// silhouette collider) — the meerkat-harvest tracer, now canvas's.
    SetNodeSprite {
        member: uuid::Uuid,
        data_uri: String,
        hull: Vec<(f32, f32)>,
    },
    /// Open another window onto the same state (rung 7): a lens — the same
    /// graph through its own camera and its OWN pane space (each window holds
    /// a frisket tree over the one App), per the one-state-N-windows doctrine.
    NewWindow,
    /// Tear the active pane out into a lens window (the tear-out trichotomy's
    /// leaf arm): the pane's frisket leaf leaves this window's tree and joins
    /// the newest lens's (spawning one when none is open). The pane's retained
    /// runner — its DOM, widget state, scroll — is untouched by the move, so
    /// identity survives BY CONSTRUCTION in the surface-compositor shape.
    TearOutActivePane,
    /// Move the active tiled pane into its space's floating layer. Its
    /// `PaneId` and retained runner remain unchanged.
    FloatActivePane,
    /// Dock the active floating pane beside a tiled peer in its current space.
    DockActivePane,
    /// Move the active floating pane from a lens back to the primary window,
    /// retaining it as a float there.
    ReturnActivePaneToPrimary,
    /// Set a node's viewer override (the settings matrix row): `None` returns
    /// to automatic routing; `Some(engine_id)` pins that lane. Persists in the
    /// browser-state sidecar and respawns live content through the pinned
    /// route, so the change is APPLIED, not merely stored.
    SetViewerOverride {
        member: uuid::Uuid,
        viewer: Option<String>,
    },
    /// Re-seed the canvas layout and replay the settle.
    ReseedLayout,
    /// Frame the camera on the current content bounds. An analytic layout can
    /// place nodes anywhere in world space (and the extent-aware Spiral spreads
    /// wide), so the view needs an explicit fit. (Projection proofs — P3.)
    FitView,
    /// Switch the canvas layout: `Some(id)` selects an analytic cartography
    /// strategy (the shell projects it per frame through the canvas's
    /// recompute gate); `None` reverts to force-directed physics. The first
    /// host wiring of the analytic catalog (projection-engine proof 1).
    SetLayoutStrategy(Option<&'static str>),
    /// Switch the physics law the graph moves under, by catalog id
    /// (`mere::canvas::PhysicsLaw::id`). (Physics catalog — P2.)
    SetPhysicsLaw(&'static str),
    /// Turn one physics overlay on or off, by catalog id.
    SetPhysicsOverlay(&'static str, bool),
    /// Where the Kinds law reads a node's kind from, by catalog id.
    SetPhysicsKindSource(&'static str),
    /// Where Orbit's masses and the hub overlays' weights come from.
    SetPhysicsMassSource(&'static str),
    /// Where the Depth overlay reads a node's depth from.
    SetPhysicsDepthSource(&'static str),
    /// Apply a named physics profile (a law plus overlays), by id.
    ApplyPhysicsProfile(&'static str),
    /// Toggle the isometric (2.5D foreshortened) view.
    ToggleIsometric,
    /// Orbit the view (yaw) by radians.
    OrbitBy(f32),
    /// Tilt the view (vertical foreshorten) by a delta.
    TiltBy(f32),
    /// Toggle height-by-degree (hubs float above the ground plane).
    ToggleHeightByDegree,
    /// Play/pause the layout physics. Global and orthogonal to the
    /// arrangement: any arrangement composes with either state (a paused
    /// Spiral holds its placement, a running one relaxes from it), and
    /// force-directed is simply no arrangement with physics running.
    TogglePhysics,
    /// Toggle size-by-recency: newest content reads largest, older shrinks.
    /// Pairs with the Spiral (newest at center, age spiralling outward) —
    /// projection-engine proof 3, the recency channel.
    ToggleSizeByRecency,
    /// Persist the session now (close path; enrichment saves ride effects).
    SaveSession,
    /// Prompt for a place name, then found one. The founding half of the
    /// vocabulary follows the rename shape: `Begin*` opens the omnibar, the
    /// commit action below carries the typed line.
    BeginFoundPlace,
    /// Found a new place in this session and open it listen-only.
    FoundPlace {
        name: String,
    },
    /// Prompt for the path a place card is written to.
    BeginExportPlaceCard,
    /// Write this place's card: binding, founder root, current rendezvous.
    /// Carries no authority and no key material.
    ExportPlaceCard {
        path: String,
    },
    /// Prompt for the card path a pre-key is offered against.
    BeginOfferPlacePrekey,
    /// Publish this profile's group identity for the card's Moot.
    OfferPlacePrekey {
        path: String,
    },
    /// The card read back by the shell, with the offer's output path.
    OfferPlacePrekeyForCard {
        card: Box<crate::place::PlaceCardV1>,
        out: String,
    },
    /// Prompt for the pre-key offer an invitation answers.
    BeginInviteToPlace,
    /// The same prompt, for an invitation that admits a reader.
    BeginInviteToPlaceAsReader,
    /// Admit one offered pre-key's root and author its invitation.
    InviteToPlace {
        path: String,
        access: crate::place::PlaceInviteAccess,
        lifetime_ms: Option<u64>,
    },
    /// The offer read back by the shell, with the invitation's output path.
    InviteToPlaceWithPrekey {
        prekey: Vec<u8>,
        out: String,
        access: crate::place::PlaceInviteAccess,
        lifetime_ms: Option<u64>,
    },
    /// Remove one member from the open place and revoke its grants.
    RevokePlaceMember {
        member: [u8; 32],
    },
    /// Prompt for the invitation file to join through.
    BeginJoinPlaceFile,
    /// Read and validate one invitation file, then join through it.
    JoinPlaceFile {
        path: String,
    },
    /// Prompt for a message body on the active place's default channel.
    BeginSendPlaceMessage,
    /// Admit an invitation into the current session, then open the place.
    ///
    /// The envelope carries no authority. Nothing durable exists for this place
    /// until every admission check has answered, so this is a request to try,
    /// not a statement that the session now belongs to a place.
    JoinPlace(Box<crate::place::invite::PlaceInviteV1>),
    /// Leave the active place locally, detaching its binding while preserving
    /// retained stores and shared membership records.
    LeavePlace,
    /// Dial saved contact hints for the currently admitted place.
    ReconnectPlace,
    /// Reconnect a locally left place, clearing its left mark. Valid only
    /// from `PlaceState::Left`.
    RejoinPlace,
    /// Inspect the current place and request fresh local sync observations.
    ShowPlaceStatus,
    /// Put this bind's full rendezvous ticket(s) on the system clipboard. The
    /// status row elides the middle of a ~200-character ticket; this is how the
    /// whole of it leaves the app.
    CopyLocalRendezvous,
    /// Send one message to a channel of the active place.
    SendPlaceMessage {
        channel: String,
        body: String,
    },
    /// Share the focused node's address into the place's shared graph.
    ShareFocusedNode,
    /// Re-fold the active place's projections from what its lanes have drained
    /// in. Cheap and idempotent; it authors nothing.
    ResyncPlace,
    /// Scope captured-page search to one exact Gemot collection version.
    /// `None` clears the local choice and searches all effective contributions.
    SetPlaceCollection(Option<crate::place::PlaceCollectionVersion>),
    /// Open the local captured-page search field for the active place.
    SearchCapturedPages,
    /// Flip the focused node's live content: spawn a document session for it
    /// through the content port, or close the one it has (rung 4; the
    /// session-engines plan's phase-4 consumer intent).
    ToggleNodeContent,
    /// Summon the omnibar (`command` pre-seeds the `>` actions lane).
    OmnibarOpen {
        command: bool,
    },
    /// Dismiss the omnibar without committing.
    OmnibarClose,
    /// Insert one typed character at the caret.
    OmnibarChar(char),
    /// Insert a string at the caret (an IME commit; later, paste).
    OmnibarInsert(String),
    /// Delete the character before the caret.
    OmnibarBackspace,
    /// Delete the character after the caret.
    OmnibarDelete,
    /// Move the caret within the omnibar text.
    OmnibarCaret(CaretMove),
    /// Move the suggestion highlight by a delta (wraps at the ends).
    OmnibarMove(i32),
    /// Commit the highlighted suggestion (or literal-go on address-shaped
    /// text with nothing highlighted).
    OmnibarCommit,
    /// Commit the suggestion row at this index — a ROW CLICK in the retained
    /// chrome (select, then the ordinary commit path).
    OmnibarCommitRow(usize),
    /// Repeat one intentional shell interaction from the bounded local
    /// transcript, preserving its captured pane context.
    RepeatShellEntry(crate::shell_services::ShellEntryId),
    /// Ask the focused-context router to reopen the original target captured
    /// by a transcript entry. A2 supplies the multi-graph router.
    OpenShellEntryTarget(crate::shell_services::ShellEntryId),
    /// Summon a pane beside the active one, splitting the frisket tree (rung 5
    /// slice C). Meerkat's fixed Right-split off the graph pane, generalized to
    /// the active pane.
    SummonPane(PaneKindId),
    /// Ask the platform shell to choose a local Knot document. The resulting
    /// path becomes a contributed source only after the user chooses it.
    ChooseKnotDocumentFile {
        read_only: bool,
    },
    /// Summon a provider-owned pane beside the active pane. The source was
    /// minted by the caller; provider admission still occurs at the render
    /// boundary, while the app preserves this exact durable value.
    SummonContributedPane {
        kind: PaneKindId,
        source: PaneSource,
    },
    /// Close the active pane, collapsing its split back into its sibling.
    CloseActivePane,
    /// Set the divider ratio of the active pane's split (drag the seam). Clamped
    /// by the geometry walker so neither side collapses.
    SetActivePaneDivider(f32),
    /// Set a split's ratio by its path — the divider drag's lowering. Redraw
    /// only; the shell saves the session once, on release. `space` names the
    /// tree the path walks (a lens's seam drags reweight the LENS's split).
    SetSplitRatio {
        space: SpaceRef,
        path: Vec<crate::panes::SplitChoice>,
        ratio: f32,
    },
    /// Toggle maximize on the active pane (a host view state; frisket has no
    /// maximize op). A maximized pane takes the whole pane area.
    ToggleMaximizePane,
    /// Add or remove a composed list section on a pane, by provider id (the
    /// gloss-composite's add/remove, offered as pane-scoped palette rows).
    /// The choice rides the pane's frisket leaf, so it persists with
    /// `frame.json` and moves with the pane on tear-out.
    TogglePaneSection {
        pane: crate::panes::PaneId,
        section: String,
    },
    /// Move a composed section earlier (`-1`) or later (`+1`) in a pane's
    /// stack. Composition ORDER is the config's order, so reordering is the
    /// same leaf edit; clamped at the ends (no wrap — a stack has a top).
    MovePaneSection {
        pane: crate::panes::PaneId,
        section: String,
        delta: i32,
    },
    /// Open the focused node as a workbench tile (rung 5 slice E): summons the
    /// Workbench pane if absent, opens the tile in platen's model, and spawns
    /// the node's content if it has none.
    OpenInWorkbench,
    /// Tear a tile OUT of the workbench — the tab drag released outside the
    /// pane. The tile leaves platen's tiling and becomes a pinned
    /// `PaneContent::Tile` pane in a lens window: the tear-out trichotomy's
    /// BRANCH arm, gesture-first (the leaf arm is `TearOutActivePane`).
    TearOutTile {
        member: uuid::Uuid,
    },
    /// Fork the connected component containing this node into a freshly
    /// minted session (the tear-out trichotomy's FORK arm, tear-out brief
    /// §4.3): new SessionId + GraphId, `parent_session` back-reference,
    /// `CopiedFrom` provenance per node, per-node character carried by facets.
    /// Gesture-first (Ctrl+Shift at the tab drag-out); the palette arm is
    /// `ForkFocusedNode`.
    ForkNode {
        member: uuid::Uuid,
    },
    /// Fork from the focused node — the palette / keyboard arm of `ForkNode`.
    ForkFocusedNode,
    /// Mint a fresh session (rung 6's second half): a new manifest under
    /// `sessions/<id>/`, then switch to it. The old session saves on the way
    /// out; the new one starts on an empty graph.
    NewSession,
    /// Switch to an existing session by id. The switcher lane (omnibar `>`)
    /// offers one of these per other session, labelled.
    SwitchSession(crate::panes::SessionId),
    /// Close the current session: trash its directory + manifest, then switch
    /// to the most-recent remaining session (minting one if it was the last).
    CloseSession,
    /// Open the omnibar in rename mode for the current session, seeded with its
    /// current label — the free-text prompt behind [`Action::RenameSession`].
    BeginRenameSession,
    /// Set a session's display name (the rename mode's commit). An empty name
    /// clears it back to the derived/uuid label.
    RenameSession {
        id: crate::panes::SessionId,
        name: String,
    },
    /// Remove the focused node from the graph ("forget this page"): its record
    /// stages into the recycle bin (the eidetic deleted-node bin, through the
    /// bin port) and the node leaves the graph. Recoverable from the Trail's
    /// Removed section until athanor permanently forgets it. Closes its live
    /// content and any workbench tile.
    DeleteFocusedNode,
    /// Recover a staged node from the recycle bin BY ITS ORIGINAL member id
    /// (a Trail Removed-row click): the node re-mints under the same uuid
    /// (identity restored), with its recorded title and tags.
    RecoverDeletedNode(uuid::Uuid),
    /// Permanently forget every staged node ("empty the recycle bin") —
    /// athanor's oven, on command. Irreversible; the records leave the store.
    EmptyRecycleBin,
    /// Stage a scenario pack (.lua) as a participant install: read + derive the
    /// content subject, then surface the VISIBLE grant review in the palette
    /// (participant gate B1). Nothing is minted or granted here.
    InstallDenizen {
        path: String,
    },
    /// Commit the staged install after the visible review: mint the participant
    /// node + binding facets, project the grant into its nested world through
    /// the servitor gate, and register the palette Run row.
    ConfirmInstallDenizen,
    /// Discard the staged install; nothing was minted.
    CancelInstallDenizen,
    /// Uninstall a resident participant: REVOKE the delegations the user granted
    /// it (cascading to anything it delegated onward) and un-reside it — the
    /// binding facet goes, the runtime entry goes. Its node and world stay,
    /// un-resided, so nothing is destroyed by revoking authority.
    UninstallDenizen {
        member: uuid::Uuid,
    },
    /// Run a resident participant's scenario body: piccolo evaluates it under a
    /// step budget, and its emitted Actions lower through this same spine
    /// with mere's GraphJournal scoped to the participant's author (attribution).
    RunDenizen {
        member: uuid::Uuid,
    },
    /// Write `body` as the content of the node at `url`, minting the node if
    /// it is not there. The authoring lane a summarizing behavior needs; the
    /// `Author` ring gates it, and that ring is never preselected.
    WriteNote {
        url: String,
        body: String,
    },
    /// Restore a trashed SESSION from the manifest trash and switch to it
    /// (overmap O3; a Trail Removed-sessions-row click). The whole session
    /// directory moved to `.trash/` intact at close, so restore is
    /// same-identity by construction.
    RecoverSession(crate::panes::SessionId),
    /// Make `member`'s tab the active (visible) one in its workbench cell.
    WorkbenchActivate(uuid::Uuid),
    /// Close the focused node's workbench tile (its cell collapses when
    /// emptied). A no-op when the focused node has no tile.
    CloseWorkbenchTile,
    /// Stack `dragged` into the cell holding `target` — the tab-drag gesture's
    /// lowering (platen's `move_to_slot_of`).
    WorkbenchStackOnto {
        dragged: uuid::Uuid,
        target: uuid::Uuid,
    },
    /// Split `dragged` out as its own cell beside `target`, on the `after`
    /// side of `axis` — the edge-drop half of the tab-drag gesture (platen's
    /// `split_beside_axis`).
    WorkbenchSplitBeside {
        dragged: uuid::Uuid,
        target: uuid::Uuid,
        axis: WbAxis,
        after: bool,
    },
    /// Split `dragged` out of its OWN cell onto that cell's edge — a tab
    /// dragged to an edge of the stack it lives in (platen's `split_out`).
    WorkbenchSplitOut {
        dragged: uuid::Uuid,
        axis: WbAxis,
        after: bool,
    },
    /// Set the fractions of the workbench split at `path` — a workbench
    /// divider drag. Redraw only; the shell saves once, on release.
    WorkbenchSetFractions {
        path: Vec<usize>,
        fractions: Vec<f32>,
    },
}

/// A workbench split axis, in the app's own vocabulary (this module stays
/// free of the tile-contract crate; `app` maps it onto pelt's `SplitAxis` at
/// the platen call). `Row` lays the new cell left/right of the target,
/// `Column` above/below.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WbAxis {
    Row,
    Column,
}

/// A caret movement within the omnibar's single line.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum CaretMove {
    Left,
    Right,
    Home,
    End,
}

/// The palette's action registry: every Action an app-intent lane (the `>`
/// omnibar lane today; automation and a context menu later) may offer, with
/// its display label. The registry is the single catalog those lanes filter;
/// an Action absent here is reachable only by its dedicated input path.
/// Every action the palette offers, label and all.
///
/// The `Layout:` rows are derived from the canvas's
/// `CANVAS_LAYOUT_STRATEGIES` registry
/// rather than written out here, so the plain arrangement names (Spiral,
/// Board, Fractal) have exactly one home and a registry rename reaches the
/// palette without a second edit. Ids stay the technical persistence keys.
pub fn palette_actions() -> Vec<(String, Action)> {
    let mut actions = vec![
        ("Back", Action::NavBack),
        ("Forward", Action::NavForward),
        ("Reload", Action::Reload),
        ("Stop loading", Action::Stop),
        (
            "Subscribe to feed: every minute",
            Action::SubscribeFocusedFeed {
                period: servitor::Period::Minute,
            },
        ),
        (
            "Subscribe to feed: hourly",
            Action::SubscribeFocusedFeed {
                period: servitor::Period::Hour,
            },
        ),
        (
            "Subscribe to feed: daily",
            Action::SubscribeFocusedFeed {
                period: servitor::Period::Day,
            },
        ),
        ("Unsubscribe from feed", Action::UnsubscribeFocusedFeed),
        ("Refresh feeds", Action::RefreshFeeds),
        ("Mark feed entry read", Action::MarkFocusedFeedEntryRead),
        ("Reseed layout", Action::ReseedLayout),
        ("Fit view", Action::FitView),
        // The per-arrangement `Layout:` rows are derived from the canvas
        // registry below, so the plain display names live in one place.
        // Force-directed is the orrery surface's native arrangement
        // (revert = None) and has no registry row of its own.
        ("Layout: Force-directed", Action::SetLayoutStrategy(None)),
        ("Toggle isometric view", Action::ToggleIsometric),
        ("Toggle height-by-degree", Action::ToggleHeightByDegree),
        ("Toggle size-by-recency", Action::ToggleSizeByRecency),
        ("Play/pause physics", Action::TogglePhysics),
        ("Orbit left", Action::OrbitBy(-0.15)),
        ("Orbit right", Action::OrbitBy(0.15)),
        ("Toggle live content", Action::ToggleNodeContent),
        ("Save session", Action::SaveSession),
        (
            "Open Knot document",
            Action::ChooseKnotDocumentFile { read_only: false },
        ),
        (
            "Open Knot document read-only",
            Action::ChooseKnotDocumentFile { read_only: true },
        ),
        (
            "Open Sky reference",
            Action::SummonContributedPane {
                kind: PaneKindId::new(crate::sky_surface::PANE_KIND),
                source: crate::sky_surface::boston_eclipse_reference_source(),
            },
        ),
    ];
    actions.extend(
        crate::panes::pane_palette_entries()
            .into_iter()
            .map(|(label, kind)| (label, Action::SummonPane(kind))),
    );
    actions.extend([
        ("New window", Action::NewWindow),
        ("Float pane", Action::FloatActivePane),
        ("Dock pane", Action::DockActivePane),
        ("Tear out pane", Action::TearOutActivePane),
        ("Return pane to primary", Action::ReturnActivePaneToPrimary),
        ("Fork from node", Action::ForkFocusedNode),
        ("Open node in Workbench", Action::OpenInWorkbench),
        ("Close workbench tile", Action::CloseWorkbenchTile),
        ("Delete node", Action::DeleteFocusedNode),
        ("Empty recycle bin", Action::EmptyRecycleBin),
        ("Close pane", Action::CloseActivePane),
        ("Maximize pane", Action::ToggleMaximizePane),
        ("New session", Action::NewSession),
        ("Rename session", Action::BeginRenameSession),
        ("Close session", Action::CloseSession),
        ("Leave place", Action::LeavePlace),
        ("Reconnect place", Action::ReconnectPlace),
        ("Rejoin place", Action::RejoinPlace),
        ("Place status", Action::ShowPlaceStatus),
    ]);

    let mut rows: Vec<(String, Action)> = actions
        .into_iter()
        .map(|(label, action)| (label.to_string(), action))
        .collect();

    // Insert the registry's arrangements ahead of Force-directed, so every
    // `Layout:` row sits together and the native arrangement closes the group.
    let anchor = rows
        .iter()
        .position(|(_, action)| matches!(action, Action::SetLayoutStrategy(None)))
        .unwrap_or(rows.len());
    for (offset, (id, display_name)) in mere::canvas::CANVAS_LAYOUT_STRATEGIES.iter().enumerate() {
        rows.insert(
            anchor + offset,
            (
                format!("Layout: {display_name}"),
                Action::SetLayoutStrategy(Some(id)),
            ),
        );
    }

    // The physics catalog's rows, derived the same way so the plain names
    // have one home: the laws, then each overlay as an on/off pair, the
    // profiles, and the three attribute sources. They follow the Layout
    // group, after Force-directed. (Physics catalog — P2.)
    let after_layout = rows
        .iter()
        .position(|(_, action)| matches!(action, Action::SetLayoutStrategy(None)))
        .map(|i| i + 1)
        .unwrap_or(rows.len());
    let mut physics: Vec<(String, Action)> = Vec::new();
    for (id, label) in mere::canvas::CANVAS_PHYSICS_LAWS {
        physics.push((format!("Physics: {label}"), Action::SetPhysicsLaw(id)));
    }
    for (id, label) in mere::canvas::CANVAS_PHYSICS_OVERLAYS {
        physics.push((
            format!("Overlay on: {label}"),
            Action::SetPhysicsOverlay(id, true),
        ));
        physics.push((
            format!("Overlay off: {label}"),
            Action::SetPhysicsOverlay(id, false),
        ));
    }
    for profile in mere::canvas::CANVAS_PHYSICS_PROFILES {
        physics.push((
            format!("Profile: {}", profile.label),
            Action::ApplyPhysicsProfile(profile.id),
        ));
    }
    for (id, label) in mere::canvas::CANVAS_PHYSICS_KIND_SOURCES {
        physics.push((format!("Kinds: {label}"), Action::SetPhysicsKindSource(id)));
    }
    for (id, label) in mere::canvas::CANVAS_PHYSICS_MASS_SOURCES {
        physics.push((format!("Mass: {label}"), Action::SetPhysicsMassSource(id)));
    }
    for (id, label) in mere::canvas::CANVAS_PHYSICS_DEPTH_SOURCES {
        physics.push((format!("Depth: {label}"), Action::SetPhysicsDepthSource(id)));
    }
    for (offset, row) in physics.into_iter().enumerate() {
        rows.insert(after_layout + offset, row);
    }

    rows
}

/// Browser controls that a hosted web surface executes directly. Retained
/// document sessions use the same app actions but complete them through the
/// fetch/content ports instead.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ContentControl {
    Back,
    Forward,
    Reload,
    Stop,
}

/// A side effect `update` asks the shell to run through a port. `update`
/// itself never blocks and never touches a platform API.
#[derive(Clone, Debug, PartialEq)]
pub enum Effect {
    /// Fetch a page document through the fetch actor, for enrichment of the
    /// node that requested it (correlation-over-URLs: several nodes may
    /// share an address, and a node may navigate away mid-flight).
    FetchPage {
        /// Process-local request identity, echoed by the fetch actor.
        request: fetch::FetchRequestId,
        /// An older request for this node that this one replaces.
        supersedes: Option<fetch::FetchRequestId>,
        node: uuid::Uuid,
        /// The address sent to the network.
        url: String,
        /// The graph address that owns the answer. Usually identical to
        /// `url`; sensitive Gemini input keeps its query out of graph truth.
        owner_url: String,
        /// A capsule-scoped client certificate selected by the host. The
        /// fetch actor still rechecks its origin on redirects.
        identity: Option<fetch::GeminiClientIdentity>,
    },
    /// Abort one exact actor-backed page request.
    CancelPage {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
    },
    /// Fetch a subscribed source without treating its response as page
    /// enrichment. It uses the same actor and capsule-scoped identity path.
    FetchFeed {
        node: uuid::Uuid,
        url: String,
        identity: Option<fetch::GeminiClientIdentity>,
    },
    /// Perform one confirmed smolweb mutation exactly once.
    SubmitSmolweb {
        request: u64,
        source: Option<uuid::Uuid>,
        target: String,
        protocol: crate::ui::SmolwebSubmissionProtocol,
        body: Vec<u8>,
        mime: String,
        token: Option<SensitiveString>,
        identity: Option<fetch::GeminiClientIdentity>,
    },
    /// Replace one durable Gemini server pin after an explicit human decision.
    /// The shell executes this synchronously before the following fetch effect.
    ReplaceGeminiTrust {
        node: uuid::Uuid,
        fetch_url: String,
        owner_url: String,
        target: String,
        pinned: String,
        seen: String,
    },
    /// Fetch a favicon (already-absolute `url`) for `node`, whose page lives
    /// at `owner_url` (the staleness check compares against it on return).
    FetchFavicon {
        node: uuid::Uuid,
        owner_url: String,
        url: String,
    },
    /// Persist one content-addressed image blob under its digest hex.
    /// The node already carries the reference and the canvas already has the
    /// decoded pixels, so this is durability only: dropping it costs a
    /// re-fetch, never correctness.
    StoreImage {
        hex: String,
        bytes: Vec<u8>,
    },
    /// Deposit a completed response in the session's representation store and
    /// write a user-visible file. The graph node remains identified by `url`;
    /// the destination returned by the shell is metadata only.
    StoreDownload {
        node: uuid::Uuid,
        url: String,
        content_type: Option<String>,
        content_disposition: Option<String>,
        received_at_ms: u64,
        bytes: Vec<u8>,
    },
    /// Persist the session through the persistence port.
    SaveSession,
    /// Put `text` on the system clipboard. The clipboard itself stays behind
    /// the shell; neither the app nor the place worker holds one.
    CopyText(String),
    /// Ask the native shell for one Djot or Knot file. A cancelled picker has
    /// no effect; an accepted path is minted into a provider-owned source.
    ChooseKnotDocumentFile {
        read_only: bool,
    },
    /// Open this session's retained place domains through the shell-owned
    /// worker. `generation` makes every later answer session-specific.
    OpenPlace {
        session: crate::panes::SessionId,
        generation: u64,
        binding: crate::place::PlaceBindingV1,
    },
    /// Found a place in this session's directory and open it listen-only.
    FoundPlace {
        session: crate::panes::SessionId,
        generation: u64,
        name: String,
    },
    /// Publish this profile's group identity for one Moot.
    OfferPlacePrekey {
        session: crate::panes::SessionId,
        generation: u64,
        moot: [u8; 32],
    },
    /// Admit one offered pre-key's root and author its invitation.
    InvitePlace {
        session: crate::panes::SessionId,
        generation: u64,
        prekey: Vec<u8>,
        access: crate::place::PlaceInviteAccess,
        lifetime_ms: Option<u64>,
    },
    /// Write one place artifact where the person asked for it. Files are a
    /// shell concern; the worker never touches the filesystem outside the
    /// session's own store.
    WritePlaceArtifact {
        path: String,
        bytes: Vec<u8>,
    },
    /// Read one place artifact and lower what it holds back into an action.
    ReadPlaceArtifact {
        path: String,
        kind: PlaceArtifactKind,
    },
    /// Admit one invitation, then open the place it names.
    ///
    /// Boxed because the envelope carries inline artifacts and every `Effect`
    /// would otherwise pay for the largest variant.
    JoinPlace {
        session: crate::panes::SessionId,
        generation: u64,
        invite: Box<crate::place::invite::PlaceInviteV1>,
    },
    /// Send one confirmed native Micron form map.  The shell owns the
    /// Reticulum link; app state only retains a redacted envelope.
    SubmitMicron {
        request: u64,
        source: Option<uuid::Uuid>,
        submission: MicronSubmission,
    },
    CancelMicronSubmission {
        request: u64,
    },
    /// Release the place worker, then mark this session's binding locally
    /// left: the binding, rendezvous hints and retained stores all stay in
    /// place, so `Rejoin` has what it needs.
    LeavePlace {
        session: crate::panes::SessionId,
        generation: u64,
        retained: crate::place::PlaceLeftSummary,
    },
    ReconnectPlace {
        session: crate::panes::SessionId,
        generation: u64,
        binding: crate::place::PlaceBindingV1,
    },
    /// Clear a local left mark. Fired alongside `ReconnectPlace` by
    /// `rejoin_place`, never on its own.
    ClearPlaceLeftMark {
        session: crate::panes::SessionId,
    },
    /// Author one fact into the active place and publish it to live peers.
    RunPlaceCommand {
        session: crate::panes::SessionId,
        generation: u64,
        request: u64,
        command: crate::place::worker::PlaceCommand,
    },
    /// Re-fold the active place's projections without touching its lanes.
    ResyncPlace {
        session: crate::panes::SessionId,
        generation: u64,
    },
    /// Change the open place's local captured-search scope and remint it.
    SetPlaceCollection {
        session: crate::panes::SessionId,
        generation: u64,
        selection: Option<crate::place::PlaceCollectionVersion>,
    },
    /// Release any retained place handles. The shell waits for acknowledgement
    /// on switch, trash, and shutdown before touching the session directory.
    ClosePlace {
        session: crate::panes::SessionId,
        generation: u64,
    },
    /// Spawn a live document session for `node` at `url` through the
    /// content port (registry-dispatched once genet-documents lands;
    /// until then the port answers with an honest ContentFailed).
    SpawnContent {
        node: uuid::Uuid,
        url: String,
    },
    /// Replace the body of an already-live incremental smolweb session.
    UpdateContent {
        node: uuid::Uuid,
        url: String,
    },
    /// Close `node`'s live session; the port drops the handle.
    CloseContent {
        node: uuid::Uuid,
    },
    /// Drive the optional web control plane of a live surface producer.
    ControlContent {
        node: uuid::Uuid,
        control: ContentControl,
    },
    /// Apply `scale` as one live surface's page zoom (`1.0` = 100%). The
    /// requested value is already persisted when this runs; a refusal from the
    /// engine changes what the document shows, never what the node stores.
    ScaleContent {
        node: uuid::Uuid,
        scale: f32,
    },
    /// Start one host-correlated viewport capture of this live web surface.
    CaptureContent {
        node: uuid::Uuid,
    },
    /// Preserve one exact, app-held fetched HTML response through the session
    /// Eidetic store. `url` is captured with the action for a stale-target gate.
    CaptureSourceDocument {
        node: uuid::Uuid,
        url: String,
    },
    /// Ask one exact live content owner to replace or step its retained find.
    FindContent {
        node: uuid::Uuid,
        request: u64,
        query: String,
        direction: DocumentFindDirection,
        find_next: bool,
    },
    ClearContentFind {
        node: uuid::Uuid,
    },
    /// Answer one exact held web-permission callback. The app captures the
    /// surface-scoped request identity in the action and the shell owns the
    /// backend callback plus durable profile registry.
    AnswerPermissionRequest {
        request: crate::user_agent_decision::UserAgentRequestKey,
        answer: inker::PermissionAnswer,
        retention: crate::web_policy::PermissionRetention,
    },
    /// Answer or cancel one exact HTTP authentication challenge. Credential
    /// values are redacted in Debug and remain process-local.
    AnswerAuthenticationRequest {
        request: crate::user_agent_decision::UserAgentRequestKey,
        credentials: Option<(SensitiveString, SensitiveString)>,
        remember_for_process: bool,
    },
    /// Open a lens window (platform work: window + surface creation) showing
    /// the pane space the app seeded at `App::lenses[ordinal]`.
    OpenWindow {
        ordinal: usize,
    },
    /// Switch the live session (port work: the shell saves the departing
    /// session, tears down its live ports — content sessions, lens windows —
    /// then has the app adopt `id` and runs the adoption's own effects).
    SwitchSession {
        id: crate::panes::SessionId,
    },
    /// Stage a removed node's record into the recycle bin (the bin port's
    /// actor persists it in the session's eidetic store and answers with the
    /// refreshed list).
    RecordDeleted {
        record: RemovedRecord,
    },
    /// Permanently forget every staged node — the bin actor clears its store
    /// and answers with the empty list ("empty the recycle bin").
    EmptyRecycleBin,
    /// Ask the trail port for lexical recall over this session's browsing
    /// memory (the omnibar's recall lane). Answered by `Update::RecallHits`
    /// carrying the query back, so a late answer to superseded text drops.
    RecallQuery {
        query: String,
    },
    /// Hand the trail port a fetched page's extracted main text, so recall
    /// reaches the body and not just the title and URL (wiring plan W6c).
    /// Best-effort like every other enrichment: dropping it costs recall
    /// reach, never correctness.
    RecordPageText {
        url: String,
        text: String,
    },
    /// Close a session (overmap O3): the shell releases the bin store (its
    /// open files block the rename on Windows), moves the closing session's
    /// whole directory to the manifest trash via `App::apply_trash`, and
    /// adopts `next` WITHOUT the departing save (a trashed session must not
    /// be resurrected as a zombie directory by a post-trash save).
    TrashSession {
        closing: crate::panes::SessionId,
        next: crate::panes::SessionId,
    },
    /// The projection is stale; present another frame.
    Redraw,
}

/// A bounded native Micron request.  Values are deliberately omitted from
/// debug output so tracing an effect cannot disclose a masked form field.
#[derive(Clone, PartialEq, Eq)]
pub struct MicronSubmission {
    pub target: String,
    pub values: std::collections::BTreeMap<String, String>,
}

impl std::fmt::Debug for MicronSubmission {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("MicronSubmission")
            .field("target", &self.target)
            .field("field_count", &self.values.len())
            .finish()
    }
}

/// A typed service answer, drained by the shell on wake and folded back into
/// state through [`crate::app::apply_update`]. App-owned types only; port
/// adapters convert.
pub enum Update {
    /// Exact Gemini response bytes arrived before the terminal fetch answer.
    PageStreamed {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
        url: String,
        response_url: String,
        content_type: Option<String>,
        bytes: Vec<u8>,
    },
    /// A page fetch completed (successfully or not) for `node`, which
    /// requested `url` (enrichment applies only while the node still lives
    /// there — a late result against a superseded node drops explicitly).
    PageFetched {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
        url: String,
        result: Result<FetchedPage, String>,
    },
    /// A subscribed feed refresh completed through the ordinary fetch port.
    FeedFetched {
        node: uuid::Uuid,
        url: String,
        result: Result<FetchedPage, String>,
    },
    SmolwebSubmitted {
        request: u64,
        source: Option<uuid::Uuid>,
        target: String,
        result: Result<SmolwebSubmissionReceipt, String>,
    },
    /// A smolweb page fetch reached a protocol input response. `url` is the
    /// member's requested address; `input_url` is the final redirect target
    /// whose query the answer must replace.
    SmolwebInputRequested {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
        url: String,
        input_url: String,
        prompt: String,
        sensitive: bool,
    },
    /// A Gemini capsule requires a client certificate. `identity_url` is the
    /// final redirect target and therefore the capsule origin the identity
    /// must be scoped to.
    GeminiIdentityRequested {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
        url: String,
        identity_url: String,
        prompt: String,
    },
    /// A Gemini TLS certificate differs from durable trust. The request was
    /// refused before application bytes and waits for an explicit decision.
    GeminiCertificateChanged {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
        url: String,
        fetch_url: String,
        target: String,
        pinned: String,
        seen: String,
    },
    /// The fetch actor confirmed that an exact page request was cancelled.
    PageStopped {
        request: fetch::FetchRequestId,
        node: uuid::Uuid,
        url: String,
    },
    /// A favicon's raw bytes arrived for `node`, requested while its page
    /// was `owner_url`.
    FaviconFetched {
        node: uuid::Uuid,
        owner_url: String,
        bytes: Vec<u8>,
    },
    /// The shell deposited a download and attempted its user-visible copy.
    DownloadStored {
        node: uuid::Uuid,
        url: String,
        content_type: Option<String>,
        content_disposition: Option<String>,
        received_at_ms: u64,
        byte_size: u64,
        result: Result<StoredDownload, String>,
    },
    /// The content port spawned a live session for `node`. `facts` carries
    /// the spawn-time mirror (engine id, the structural read's summary) in
    /// app-owned terms — the adapter converts the service's report type at
    /// the boundary, like every other port answer.
    ContentSpawned {
        node: uuid::Uuid,
        facts: Option<crate::content::ContentFacts>,
    },
    DocumentFindChanged {
        node: uuid::Uuid,
        request: u64,
        query: String,
        result: Result<DocumentFindModel, String>,
    },
    PermissionRequested {
        node: uuid::Uuid,
        id: inker::UserAgentRequestId,
        origin: String,
        descriptors: Vec<inker::PermissionDescriptor>,
    },
    AuthenticationRequested {
        node: uuid::Uuid,
        id: inker::UserAgentRequestId,
        host: String,
        port: u16,
        realm: Option<String>,
        scheme: String,
        is_proxy: bool,
    },
    PermissionRequestFinished {
        request: crate::user_agent_decision::UserAgentRequestKey,
        answer: inker::PermissionAnswer,
        retention: crate::web_policy::PermissionRetention,
        terminal: bool,
        result: Result<(), String>,
    },
    AuthenticationRequestFinished {
        request: crate::user_agent_decision::UserAgentRequestKey,
        supplied_credentials: bool,
        remember_for_process: bool,
        terminal: bool,
        result: Result<(), String>,
    },
    UserAgentRequestWithdrawn {
        request: crate::user_agent_decision::UserAgentRequestKey,
        kind: &'static str,
        reason: &'static str,
    },
    /// The content port could not spawn (or lost) `node`'s session.
    ContentFailed { node: uuid::Uuid, error: String },
    /// The recycle bin's current contents (the bin port answers every record
    /// / reopen with the refreshed list, and emits one on spawn). Replaces the
    /// app's cache wholesale.
    BinListed { records: Vec<RemovedRecord> },
    /// The bin store failed (open / record / list) — loud and attributable,
    /// never an empty list masquerading as "nothing deleted".
    BinFailed { error: String },
    /// Lexical recall over browsing memory answered. `query` is the text the
    /// hits answer; the app drops an answer whose query is no longer what the
    /// omnibar holds (the keystroke that superseded it wins).
    RecallHits { query: String, hits: Vec<RecallHit> },
    /// Recall could not answer (no index yet, a re-mint failure, a broken
    /// store). Loud: a recall lane that silently shows nothing is
    /// indistinguishable from a trail with nothing in it.
    RecallFailed { error: String },
    /// The session Eidetic actor completed an explicit source-document capture.
    SourceDocumentCaptured {
        node: uuid::Uuid,
        url: String,
        result: Result<StoredSourceDocument, String>,
    },
    /// One retained-place open completed. The app accepts it only while both
    /// the session and generation still match its active opening.
    PlaceOpened {
        session: crate::panes::SessionId,
        generation: u64,
        result: Result<crate::place::OfflinePlaceSnapshot, String>,
    },
    /// A dial to the mere holding a place-held Knot document is prepared, or
    /// could not be. The shell opens it on a visiting thread of its own; the
    /// app only learns that a visit is open or why it was refused.
    // The dial is a crate-internal handle in a crate-internal module; this
    // vocabulary is public only because everything in it is.
    #[allow(private_interfaces)]
    PlaceDocumentVisit {
        session: crate::panes::SessionId,
        generation: u64,
        request: u64,
        holder_root: [u8; 32],
        path: String,
        result: Result<Box<crate::place::lanes::HolderDial>, String>,
    },
    /// The place's live lanes accepted operations and have settled.
    ///
    /// A nudge, not a projection: the watcher samples counters and cannot
    /// apply the authority filter, which belongs with the stores. The app
    /// answers by asking for a resync, so what arrived becomes visible through
    /// exactly the same fold every other path uses.
    PlaceLanesAdvanced {
        session: crate::panes::SessionId,
        generation: u64,
    },
    /// One authored place command completed.
    ///
    /// Success carries the re-folded snapshot, because authoring changes what
    /// the place projects and the app should never keep a stale view of state
    /// it just changed. Failure changes no state: an unauthorized or malformed
    /// command is reported, not absorbed.
    PlaceCommandDone {
        session: crate::panes::SessionId,
        generation: u64,
        request: u64,
        result: Result<crate::place::OfflinePlaceSnapshot, String>,
    },
    /// A local captured-search collection choice was resolved and reminted.
    /// Failure retains the prior snapshot because it authored nothing.
    PlaceCollectionSet {
        session: crate::panes::SessionId,
        generation: u64,
        result: Result<crate::place::OfflinePlaceSnapshot, String>,
    },
    /// One invitation admission completed.
    ///
    /// One place was founded here, and is open listen-only.
    ///
    /// Distinct from [`Update::PlaceJoined`]: nothing was admitted, because
    /// there was nothing to be admitted into until this succeeded.
    PlaceFounded {
        session: crate::panes::SessionId,
        generation: u64,
        result: Result<
            (
                crate::place::PlaceBindingV1,
                crate::place::OfflinePlaceSnapshot,
            ),
            String,
        >,
    },
    /// This profile's published group pre-key for one Moot. An offer, not an
    /// admission: holding it grants the holder nothing.
    PlacePrekeyOffered {
        session: crate::panes::SessionId,
        generation: u64,
        result: Result<Vec<u8>, String>,
    },
    /// One authored invitation for an offered pre-key.
    PlaceInvited {
        session: crate::panes::SessionId,
        generation: u64,
        result: Result<Box<crate::place::invite::PlaceInviteV1>, String>,
    },
    /// Distinct from [`Update::PlaceOpened`] because the failure means
    /// something different: an open that fails leaves a degraded but real
    /// place, while an admission that fails means there is no place at all.
    /// The binding travels in the success arm because until admission returns
    /// it, the app has no admitted binding to name.
    PlaceJoined {
        session: crate::panes::SessionId,
        generation: u64,
        result: Result<
            (
                crate::place::PlaceBindingV1,
                crate::place::OfflinePlaceSnapshot,
            ),
            String,
        >,
    },
}

/// Manifest identities written by one explicit source-document capture.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct StoredSourceDocument {
    pub raw_manifest: String,
    pub annotation_manifest: String,
}

/// A successfully fetched page document, in app-owned terms.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FetchedPage {
    /// The response's Content-Type header, verbatim.
    pub content_type: Option<String>,
    /// The response's Content-Disposition header, when the protocol has one.
    pub content_disposition: Option<String>,
    /// Exact response bytes, before replacement-character text decoding.
    pub bytes: Vec<u8>,
    /// The decoded body text.
    pub body: String,
}

impl FetchedPage {
    pub fn text(content_type: Option<String>, body: impl Into<String>) -> Self {
        let body = body.into();
        let bytes = body.as_bytes().to_vec();
        Self {
            content_type,
            content_disposition: None,
            bytes,
            body,
        }
    }
}

/// Host-written facts for one completed download.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct StoredDownload {
    pub content: mere::kernel::graph::ContentHash,
    pub destination: String,
    pub byte_size: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SmolwebSubmissionReceipt {
    Success(FetchedPage),
    Redirect(String),
}

/// One recall hit from browsing memory, in app-owned terms. The trail port
/// converts its lexical/vector projection at the boundary, like the bin does
/// with `DeletedNode`.
#[derive(Clone, Debug, PartialEq)]
pub struct RecallHit {
    pub url: String,
    pub title: Option<String>,
    /// When the traversal this hit indexes happened, unix milliseconds.
    pub at_ms: u64,
}

/// A staged (deleted) node's record in the recycle bin, in app-owned terms
/// (the port adapter converts eidetic's `DeletedNode` at the boundary).
/// Carries the ORIGINAL member id, so recovery restores identity.
#[derive(Clone, Debug, PartialEq)]
pub struct RemovedRecord {
    pub node_id: uuid::Uuid,
    pub url: String,
    pub title: Option<String>,
    pub tags: Vec<String>,
    /// Deletion time, unix milliseconds (the bin's newest-first ordering).
    pub deleted_at_ms: u64,
    /// The world the node BORE at deletion (`Node.nested`, string form) —
    /// its file sits in the archive slot while this record stands; recovery
    /// re-bears it, purging the record purges the file.
    pub nested: Option<String>,
    /// The node's facet bundle at deletion (facet-id -> payload), restored
    /// whole on recovery: residency binding, arrangement, web state.
    pub facets: Option<serde_json::Value>,
}
