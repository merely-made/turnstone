// Copyright 2026 Mark Alan Boykin
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0

use crate::action::{DocumentFindDirection, DocumentFindModel, Effect};

use super::App;

impl App {
    pub(super) fn open_document_find(&mut self) -> Vec<Effect> {
        let Some((target, _)) = self.browser_command_target() else {
            return vec![Effect::Redraw];
        };
        if !matches!(
            self.content.get(target),
            Some(crate::content::NodeContent::Live)
        ) {
            return vec![Effect::Redraw];
        }
        let Some(find_capability) = self
            .content
            .facts(target)
            .map(|facts| facts.capabilities.find_in_page.clone())
        else {
            self.events
                .push(crate::observe::AppEvent::AffordanceUnavailable {
                    what: "find-in-document",
                    target: "live engine did not report document capabilities".to_string(),
                });
            return vec![Effect::Redraw];
        };
        if !find_capability.is_available() {
            self.events
                .push(crate::observe::AppEvent::AffordanceUnavailable {
                    what: "find-in-document",
                    target: find_capability.describe(),
                });
            return vec![Effect::Redraw];
        }
        let mut effects = if self.omnibar.open {
            self.close_omnibar()
        } else {
            Vec::new()
        };
        // Action-row commits clear the visible omnibar before lowering the
        // chosen Action. Clear its captured shell context here as well.
        self.shell.close_omnibar();
        if self.document_find.target != Some(target) {
            if let Some(previous) = self.document_find.target {
                effects.push(Effect::ClearContentFind { node: previous });
            }
            let request = self.document_find.request;
            self.document_find = crate::document_find::DocumentFindState {
                request,
                ..Default::default()
            };
        }
        self.document_find.open = true;
        self.document_find.target = Some(target);
        effects.push(Effect::Redraw);
        effects
    }

    pub(super) fn close_document_find(&mut self) -> Vec<Effect> {
        let target = self.document_find.target;
        self.document_find.request = self.document_find.request.wrapping_add(1).max(1);
        self.document_find.open = false;
        self.document_find.target = None;
        self.document_find.pending = false;
        self.document_find.model = DocumentFindModel::default();
        self.document_find.error = None;
        let mut effects = target
            .map(|node| Effect::ClearContentFind { node })
            .into_iter()
            .collect::<Vec<_>>();
        effects.push(Effect::Redraw);
        effects
    }

    pub(super) fn insert_document_find(&mut self, text: String) -> Vec<Effect> {
        if !self.document_find.open || text.is_empty() {
            return Vec::new();
        }
        self.document_find.query.push_str(&text);
        self.replace_document_find()
    }

    pub(super) fn backspace_document_find(&mut self) -> Vec<Effect> {
        if !self.document_find.open || self.document_find.query.pop().is_none() {
            return Vec::new();
        }
        self.replace_document_find()
    }

    fn replace_document_find(&mut self) -> Vec<Effect> {
        let Some(node) = self.document_find.target else {
            return vec![Effect::Redraw];
        };
        self.document_find.request = self.document_find.request.wrapping_add(1).max(1);
        self.document_find.pending = !self.document_find.query.is_empty();
        self.document_find.model = DocumentFindModel::default();
        self.document_find.error = None;
        if self.document_find.query.is_empty() {
            return vec![Effect::ClearContentFind { node }, Effect::Redraw];
        }
        vec![
            Effect::FindContent {
                node,
                request: self.document_find.request,
                query: self.document_find.query.clone(),
                direction: DocumentFindDirection::Next,
                find_next: false,
            },
            Effect::Redraw,
        ]
    }

    pub(super) fn step_document_find(&mut self, direction: DocumentFindDirection) -> Vec<Effect> {
        let Some(node) = self.document_find.target else {
            return Vec::new();
        };
        if !self.document_find.open || self.document_find.query.is_empty() {
            return Vec::new();
        }
        self.document_find.request = self.document_find.request.wrapping_add(1).max(1);
        self.document_find.pending = true;
        self.document_find.error = None;
        vec![Effect::FindContent {
            node,
            request: self.document_find.request,
            query: self.document_find.query.clone(),
            direction,
            find_next: true,
        }]
    }

    pub(super) fn apply_document_find_changed(
        &mut self,
        node: uuid::Uuid,
        request: u64,
        query: String,
        result: Result<DocumentFindModel, String>,
    ) -> Vec<Effect> {
        if !self.document_find.open
            || self.document_find.target != Some(node)
            || self.document_find.request != request
            || self.document_find.query != query
        {
            return Vec::new();
        }
        self.document_find.pending = result.as_ref().is_ok_and(|model| !model.complete);
        match result {
            Ok(model) => {
                self.document_find.model = model;
                self.document_find.error = None;
            },
            Err(error) => {
                self.document_find.model = DocumentFindModel::default();
                self.document_find.error = Some(error);
            },
        }
        vec![Effect::Redraw]
    }

    pub(crate) fn invalidate_document_find_for(&mut self, node: uuid::Uuid) -> Vec<Effect> {
        if self.document_find.target == Some(node) {
            self.close_document_find()
        } else {
            Vec::new()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::action::{Action, DocumentFindMatch, Update};
    use crate::content::{CapabilityStatus, ContentFacts, DocumentCapabilityFacts};

    fn note_findable(app: &mut App, node: uuid::Uuid) {
        app.content.note_live(
            node,
            Some(ContentFacts {
                engine: "test.document".into(),
                structure: None,
                lineage: None,
                capabilities: DocumentCapabilityFacts {
                    find_in_page: CapabilityStatus::Supported,
                    ..Default::default()
                },
            }),
        );
    }

    #[test]
    fn workbench_find_and_zoom_follow_the_browser_page_with_an_independent_graph_cursor() {
        let mut app = App::test_stub();
        app.update(Action::OpenAddress("https://example.test/a".into()));
        let a = app.graph_runtimes.focused_member().unwrap();
        app.update(Action::OpenInWorkbench);
        app.update(Action::OpenAddress("https://example.test/b".into()));
        let b = app.graph_runtimes.focused_member().unwrap();
        app.update(Action::OpenInWorkbench);
        app.content.note_live(
            a,
            Some(ContentFacts {
                engine: "test.document".into(),
                structure: None,
                lineage: None,
                capabilities: DocumentCapabilityFacts {
                    find_in_page: CapabilityStatus::Supported,
                    page_zoom: CapabilityStatus::Supported,
                    ..Default::default()
                },
            }),
        );
        app.content.note_live(b, None);
        app.update(Action::WorkbenchActivate(a));
        assert_eq!(app.graph_runtimes.focused_member(), Some(b));
        let actions = app.available_actions();
        assert!(actions.iter().any(|(label, _)| label == "Find in document"));
        assert!(
            actions
                .iter()
                .any(|(_, action)| matches!(action, Action::PageZoomIn { member } if *member == a))
        );
        app.update(Action::OpenDocumentFind);
        assert_eq!(app.document_find.target, Some(a));
        let effects = app.update(Action::InsertDocumentFind("needle".into()));
        assert!(
            effects
                .iter()
                .any(|effect| matches!(effect, Effect::FindContent { node, .. } if *node == a))
        );
        assert_eq!(app.graph_runtimes.focused_member(), Some(b));
        app.update(Action::CloseDocumentFind);
        app.content.note_live(a, None);
        note_findable(&mut app, b);
        assert!(
            !app.available_actions()
                .iter()
                .any(|(label, _)| label == "Find in document")
        );
        assert!(
            !app.available_actions()
                .iter()
                .any(|(_, action)| matches!(action, Action::PageZoomIn { .. }))
        );
        app.update(Action::OpenDocumentFind);
        assert!(!app.document_find.open);
    }

    #[test]
    fn unsupported_engine_neither_offers_nor_opens_find() {
        let mut app = App::test_stub();
        app.update(Action::OpenAddress("https://example.test/opaque".into()));
        let node = app.graph_runtimes.focused_member().expect("focused member");
        app.content.note_live(
            node,
            Some(ContentFacts {
                engine: "test.opaque".into(),
                structure: None,
                lineage: None,
                capabilities: DocumentCapabilityFacts {
                    find_in_page: CapabilityStatus::Unsupported {
                        reason: "opaque surface has no text search".into(),
                    },
                    ..Default::default()
                },
            }),
        );

        assert!(
            !app.available_actions()
                .iter()
                .any(|(label, _)| label == "Find in document")
        );
        let effects = app.update(Action::OpenDocumentFind);
        assert!(!app.document_find.open);
        assert_eq!(effects, vec![Effect::Redraw]);
        assert!(app.take_events().iter().any(|event| matches!(
            event,
            crate::observe::AppEvent::AffordanceUnavailable { what, target }
                if *what == "find-in-document"
                    && target.contains("opaque surface has no text search")
        )));
    }

    #[test]
    fn captured_target_and_request_drop_late_find_results() {
        let mut app = App::test_stub();
        app.update(Action::OpenAddress("gemini://example.test/find".into()));
        let node = app.graph_runtimes.focused_member().expect("focused member");
        note_findable(&mut app, node);

        app.update(Action::OpenDocumentFind);
        let effects = app.update(Action::InsertDocumentFind("needle".into()));
        let (request, query) = effects
            .iter()
            .find_map(|effect| match effect {
                Effect::FindContent { request, query, .. } => Some((*request, query.clone())),
                _ => None,
            })
            .expect("typed find effect");
        app.update(Action::InsertDocumentFind("s".into()));

        let effects = app.apply_update(Update::DocumentFindChanged {
            node,
            request,
            query,
            result: Ok(DocumentFindModel {
                count: 1,
                matches: vec![DocumentFindMatch {
                    label: "late".into(),
                    role: Some("paragraph".into()),
                }],
                current: Some(0),
                complete: true,
            }),
        });
        assert!(effects.is_empty());
        assert!(app.document_find.model.matches.is_empty());

        let effects = app.invalidate_document_find_for(node);
        assert!(effects.contains(&Effect::ClearContentFind { node }));
        assert!(!app.document_find.open);
    }

    #[test]
    fn current_match_is_observable_and_accessible() {
        let mut app = App::test_stub();
        app.update(Action::OpenAddress("gemini://example.test/find".into()));
        let node = app.graph_runtimes.focused_member().expect("focused member");
        note_findable(&mut app, node);
        app.update(Action::OpenDocumentFind);
        let effects = app.update(Action::InsertDocumentFind("needle".into()));
        let request = effects
            .iter()
            .find_map(|effect| match effect {
                Effect::FindContent { request, .. } => Some(*request),
                _ => None,
            })
            .expect("find request");
        app.apply_update(Update::DocumentFindChanged {
            node,
            request,
            query: "needle".into(),
            result: Ok(DocumentFindModel {
                count: 2,
                matches: vec![
                    DocumentFindMatch {
                        label: "Needle heading".into(),
                        role: Some("heading".into()),
                    },
                    DocumentFindMatch {
                        label: "needle paragraph".into(),
                        role: Some("paragraph".into()),
                    },
                ],
                current: Some(0),
                complete: true,
            }),
        });

        let view = crate::observe::snapshot(&app)
            .document_find
            .expect("find is observed");
        assert_eq!(view.target, node);
        assert_eq!(view.count, 2);
        assert_eq!(view.current, Some(0));
        assert_eq!(view.current_role.as_deref(), Some("heading"));
        assert_eq!(view.current_label.as_deref(), Some("Needle heading"));
        assert_eq!(view.status, "1 of 2 · heading: Needle heading");
        let lines = crate::a11y::a11y_lines(&app);
        assert!(
            lines
                .iter()
                .any(|line| line == "searchinput: Find in document = needle")
        );
        assert!(
            lines
                .iter()
                .any(|line| { line == "status: 1 of 2 · heading: Needle heading" })
        );
    }

    #[test]
    fn engine_managed_count_is_observed_without_synthetic_matches() {
        let mut app = App::test_stub();
        app.update(Action::OpenAddress("https://example.test/find".into()));
        let node = app.graph_runtimes.focused_member().expect("focused member");
        note_findable(&mut app, node);
        app.update(Action::OpenDocumentFind);
        let effects = app.update(Action::InsertDocumentFind("needle".into()));
        let request = effects
            .iter()
            .find_map(|effect| match effect {
                Effect::FindContent { request, .. } => Some(*request),
                _ => None,
            })
            .expect("find request");
        app.apply_update(Update::DocumentFindChanged {
            node,
            request,
            query: "needle".into(),
            result: Ok(DocumentFindModel {
                count: 3,
                matches: Vec::new(),
                current: Some(1),
                complete: true,
            }),
        });

        let view = crate::observe::snapshot(&app)
            .document_find
            .expect("find is observed");
        assert_eq!(view.count, 3);
        assert_eq!(view.current, Some(1));
        assert_eq!(view.status, "2 of 3");
        assert_eq!(view.current_role, None);
        assert_eq!(view.current_label, None);
    }
}
