// Copyright 2026 Mark Alan Boykin
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0

//! The self-drive scenario lane: the app drives ITSELF from a scenario file,
//! so headed receipts need no OS synthetic input — no focus race, no key
//! theft when a human is using the machine (the SendKeys lane's unfixable
//! failure mode). This is the vocabulary's first automation consumer (the
//! architecture plan's recorded trigger): every step lowers to an ordinary
//! [`Action`] through the same `update` spine as a keypress, so the runner
//! needs no second execution model.
//!
//! Activation: set `TURNSTONE_SCENARIO` to a scenario file path before launch;
//! captures land in `TURNSTONE_CAPTURE_DIR` (default: beside the scenario).
//! The run ends by writing `scenario.done` there — first line `RESULT ok` or
//! `RESULT fail`, then the log lines — and exiting WITHOUT saving the
//! session, so a scenario never mutates the profile it ran against and
//! reruns stay deterministic.
//!
//! Grammar (one verb per line, `#` comments):
//!
//! ```text
//! settle [frames]           # pump N frames (default 20)
//! capture <name>            # self-capture the composed frame -> <name>.png
//! open <url>                # Action::OpenAddress (use mere:// for offline)
//! omnibar find|actions      # Action::OmnibarOpen
//! type <text>               # Action::OmnibarChar per char
//! insert <text>             # IME commit into the focused omnibar or Knot editor
//! key enter|escape|tab|backspace|delete|up|down|left|right|home|end|ctrl+s
//! act <palette label>       # commit a palette_actions() entry by label
//! script <inline lua>        # run a Piccolo control script; its Actions lower
//!                            # through the same spine (the automation runner —
//!                            # needs the `piccolo` feature)
//! click-at <x> <y>          # pointer click at window px (content links, canvas)
//! press-at <x> <y>          # mouse down, retained until release-at
//! release-at <x> <y>        # mouse up after intervening frames/moves
//! move-at <x> <y>           # pointer hover at window px (cursor/hover receipts)
//! touch-at <id> down|move|up|cancel <x> <y> [pressure]
//!                           # one direct contact through Pointer Events
//! right-click-at <x> <y>    # right-click: opens the command palette, selecting
//!                           # the node under the pointer (the context menu)
//! click-row <substr>       # click the list-pane row whose text contains substr
//! scroll <x> <y> <dy>       # wheel at window px (page scroll / canvas pan)
//! scroll-reader <role> <dy> # wheel at the live Reader inset|workbench|tile rect
//! record-reader-appearances <name> # stable sorted Reader appearance observation
//! record-idle <name>        # bounded global-idle diagnosis after a wait
//! divider <ratio>           # set the active pane's split ratio (0.0-1.0)
//! assert pane <tag>         # a pane with that PaneContent tag is in the tree
//! assert maximized | not-maximized
//! drop-file <x> <y> <path>  # drop a file at window px (image on node = sprite;
//!                           # else it becomes a file:// node)
//! hover-file <x> <y> <path> # begin/continue the OS file-drag lifecycle
//! drag-tab <a> onto <b>     # drag workbench tab <a> onto tab <b>'s cell (stack)
//! drag-tab <a> onto <b> @ <edge>  # ...releasing on the cell's left|right|top|bottom
//!                           # edge band (split beside instead of stack)
//! drag-tab <a> out          # ...releasing OUTSIDE the workbench (on the canvas):
//!                           # the tile tears out into a lens window (branch arm)
//! assert row <substr>       # a Trail/Roster/Inspector row's text contains substr
//! assert no-row <substr>    # NO list-pane row contains substr
//! assert wb-cells ==|>=|<= <n>  # the workbench has n cells
//! assert wb-cell <substr>   # a workbench cell's tab string contains substr
//! assert wb-fraction ==|>=|<= <f>  # the workbench root split's FIRST fraction
//! assert a11y <substr>      # an a11y-projection line ("role: label") contains substr
//! assert lens-pane <substr> # a lens window's "ordinal:tag" pane contains substr
//! assert lens-surface <kind> # the FIRST lens window's live plan composites that kind
//! assert no-pane <tag>      # NO pane with that tag is in the PRIMARY tree
//! assert no-lens-pane <substr> # NO lens "ordinal:tag" pane contains substr
//! assert no-surface <kind>  # NO surface of that kind in the PRIMARY plan
//! assert reader-appearances ==|>=|<= <n> # live Reader presentations in the plan
//! assert reader-sources ==|>=|<= <n> # distinct Reader source documents
//! assert reader-role <role> # exactly one live Reader role
//! assert reader-viewport <role> # session viewport matches its live rect
//! assert reader-scroll <role> ==|>=|<= <px> # role's own retained scroll offset
//! assert content-sessions-idle # every live document session has settled
//! assert content-ready # fetches, content requests, and sessions are quiet
//! wait-row <frames> <substr> # like `assert row`, re-checked once per pumped
//!                            # frame for up to <frames> frames; passes the
//!                            # moment it matches, fails with `assert row`'s
//!                            # diagnostics if the budget runs out
//! wait-status <frames> <substr> # like wait-row, over the place status lines
//!                            # (`crate::observe::snapshot(..).place_status`)
//! wait-file <frames> <path>  # like wait-row, satisfied once <path> exists
//!                            # and is non-empty (cross-process sequencing
//!                            # through an exchange directory)
//! wait-knot <frames> <substr> # like wait-row, over this session's
//!                            # `crate::observe::KnotDocumentFacts` (from
//!                            # `App::knot_documents()`), each entry read as
//!                            # "<status> <address>" (e.g. "visiting
//!                            # knot://<root>/field.knot")
//! record-place <name>        # write crate::observe::place_record(..), pretty
//!                            # printed, to <name>.json in the capture dir
//! touch <path>               # write a one-line marker file at <path> (any
//!                            # absolute path, not just the capture dir) —
//!                            # a cross-process signal a scenario can wait on
//!                            # with wait-file from another process
//! assert active-ratio ==|>=|<= <f> # the ACTIVE pane's parent-split ratio (any space)
//! assert sessions ==|>=|<= <n>  # the manifest set holds n sessions
//! assert session <substr>   # the live session's label contains substr
//! assert nodes ==|>=|<= <n> # the graph holds n nodes
//! capture-lens <name>       # self-capture the first lens window's frame
//! assert omnibar open|closed
//! assert omnibar-text <str>  # the omnibar text is exactly <str>
//! assert focused <substr>   # focused node's url/caption contains substr
//! assert surface <kind>     # a surface of that kind (canvas|content|chrome) is composited
//! assert focus <kind>       # semantic input goes to that surface kind
//! assert suggestions ==|>=|<= <n>
//! assert visible            # at least one node inside the viewport
//! assert event <substr>     # a semantic event matching <substr> was emitted
//! log <text>
//! ```
//!
//! Asserts read the observation surface ([`crate::observe`]) — the same
//! snapshot/event pair the a11y and automation lanes consume — so a green
//! scenario certifies the surface those lanes will stand on.
//!
//! Every line is expanded for `${NAME}` before parsing: each occurrence is
//! replaced with the process environment variable of that name (a missing
//! variable is a parse error, named by line). This lets one scenario file
//! reference a path chosen by its driver (an exchange directory, say)
//! without hardcoding it — see `wait-file` above and `scenarios/place_*.scn`.

/// One parsed scenario step. `TURNSTONE_SCENARIO` runs on the shared
/// `taproot::Scenario` loop; the generic verbs (act/settle/capture/log,
/// assert text/event/snap) it owns, and these app-specific steps reach the Shell
/// via `Driveable::app_step`, parsed here and run by `Shell::run_scenario_step`.
#[derive(Debug)]
pub enum Step {
    Open(String),
    Omnibar {
        command: bool,
    },
    Type(String),
    Insert(String),
    Key(EditKey),
    Act(String),
    /// A Piccolo control script whose emitted Actions lower through the spine
    /// (the "one description, two runners" automation lane). Piccolo-gated.
    Script(String),
    /// A pointer press+release at window pixel coordinates (rung 5 slice B).
    /// Drives the same surface-routed path winit does; a click on content
    /// resolves links, a click on the canvas is a canvas gesture.
    Click(f32, f32),
    Press(f32, f32),
    Release(f32, f32),
    /// A pointer move at window pixel coordinates. This is separately
    /// driveable so cursor and hover callbacks can be received before a click.
    Move(f32, f32),
    /// One direct touch contact. The caller's u64 id is translated to a live,
    /// collision-free Pointer Events id by the same seam winit drives.
    Touch(u64, inker::PointerPhase, f32, f32, Option<f32>),
    /// A right-click at window pixel coordinates: opens the command palette,
    /// selecting the graph node under the pointer first (the context menu).
    RightClick(f32, f32),
    /// A wheel event at window pixel coordinates: content scrolls, canvas pans.
    Scroll(f32, f32, f32, f32),
    /// A wheel event at the centre of a named, live Reader appearance. The
    /// shell resolves the rect from its current plan, so the receipt names a
    /// presentation role rather than relying on a fixed window coordinate.
    ScrollReader(String, f32),
    /// Write the live Reader appearance registry/plan intersection as a
    /// scenario receipt, sorted by stable surface id.
    RecordReaderAppearances(String),
    /// Write the named reasons that currently make Turnstone's global `wait`
    /// report busy. This is a read-only receipt, not another waiting policy.
    RecordIdle(String),
    /// Click the list-pane (Trail/Roster) row whose text contains this substring.
    /// The shell resolves the row's window position (it owns the pane rects and
    /// rows), so the receipt names a row by text, not pixels.
    ClickRow(String),
    /// Click the Roster's tab by label; the shell asks the strip where it is.
    ClickTab(String),
    /// Click the Gloss minimap's node by label/url substring.
    ClickNode(String),
    /// Press at the first point, move through it, release at the second.
    Drag((f32, f32), (f32, f32)),
    /// Drag the workbench tab labelled like the first substring onto the cell
    /// of the tab labelled like the second (the stack gesture, by name). The
    /// optional edge releases on that band of the cell body (split beside).
    DragTab(String, String, Option<String>),
    /// Drag workbench tab <a> and release OUTSIDE the workbench pane (on the
    /// canvas) — the tile tear-out gesture (the trichotomy's branch arm).
    DragTabOut(String),
    /// Drop the file at window `(x, y)` — the same handler winit's
    /// `DroppedFile` drives.
    DropFile(f32, f32, String),
    /// Hover the file at window `(x, y)` — the same handler winit's
    /// `HoveredFile` drives, allowing Chromium to answer `dragover` before a
    /// later `DroppedFile` turn.
    HoverFile(f32, f32, String),
    /// The workbench has this many cells.
    AssertWbCells(CmpOp, usize),
    /// A workbench cell's tab string contains this substring.
    AssertWbCell(String),
    /// The workbench root split's FIRST fraction compares as given.
    AssertWbFraction(CmpOp, f32),
    /// An a11y-projection line contains this substring.
    AssertA11y(String),
    /// The window count (primary + lenses) compares as given.
    AssertWindows(CmpOp, usize),
    /// A lens window holds a pane whose "ordinal:tag" contains the substring.
    AssertLensPane(String),
    /// The FIRST lens window's live surface plan composites a surface of the
    /// named kind (the tiles-follow-the-pane receipt).
    AssertLensSurface(String),
    /// NO pane with the given tag is in the PRIMARY tree (the tear-out's
    /// departure half).
    AssertNoPane(String),
    /// NO surface of the named kind is in the PRIMARY plan (the one-session-
    /// one-surface rule's cross-window half).
    AssertNoSurface(String),
    AssertReaderAppearances(CmpOp, usize),
    AssertReaderSources(CmpOp, usize),
    AssertReaderRole(String),
    AssertReaderViewport(String),
    AssertReaderScroll(String, CmpOp, f32),
    /// The document-session portion of quiescence. Graph layout may still be
    /// moving, so this deliberately does not claim whole-app idle.
    AssertContentSessionsIdle,
    AssertContentReady,
    /// NO lens pane's "ordinal:tag" contains the substring (the lens close
    /// op's departure half).
    AssertNoLensPane(String),
    /// The ACTIVE pane's parent-split ratio compares as given, in whichever
    /// space holds the pane — the divider op's readback, primary or lens.
    AssertActiveRatio(CmpOp, f32),
    /// The manifest set's session count compares as given.
    AssertSessions(CmpOp, usize),
    /// The live session's label contains this substring.
    AssertSession(String),
    /// The graph's node count compares as given (a switch shows a different
    /// graph; this is the cheap witness).
    AssertNodes(CmpOp, usize),
    /// `assert energy <op> <n>` / `assert overlaps <op> <n>`: the layout's
    /// kinetic energy and its overlapping pairs. (Physics catalog — P4.)
    AssertEnergy(CmpOp, f32),
    /// `assert physics running|paused`.
    AssertPhysicsRunning(bool),
    AssertOverlaps(CmpOp, usize),
    /// Self-capture the first live lens window's composed frame.
    CaptureLens(String),
    /// The root split's ratio compares as given.
    AssertRatio(CmpOp, f32),
    Settle(u32),
    Capture(String),
    AssertOmnibar(bool),
    /// Whether the last content scroll key moved the focused page (`moved`) or
    /// was an honest no-op at the end (`still`).
    AssertScrolled(bool),
    AssertText(String),
    AssertFocused(String),
    /// The focused node's browser fetch phase contains this receipt substring.
    AssertBrowserFetch(String),
    /// The prospective-node link preview contains this receipt substring.
    AssertLinkPreview(String),
    /// A named surface kind ("canvas" / "content" / "chrome" / "pane") is in the plan.
    AssertSurface(String),
    /// The focus target is a named surface kind.
    AssertFocus(String),
    /// A pane with the given `PaneContent` tag is in the frisket tree.
    AssertPane(String),
    /// Whether a pane is maximized.
    AssertMaximized(bool),
    /// A list/detail pane row's text contains this substring.
    AssertRow(String),
    /// NO list-pane row contains this substring.
    AssertNoRow(String),
    AssertTab(String),
    /// Set the active pane's divider ratio (drag the seam).
    Divider(f32),
    AssertSuggestions(CmpOp, usize),
    AssertVisible,
    /// The focused node's content lifecycle is Live (the phase-4 receipt's
    /// app-truth half; the capture is the pixel half).
    AssertContentLive,
    /// A semantic event whose description contains the substring was emitted
    /// at some point this run.
    AssertEvent(String),
    /// Like [`Step::AssertRow`], but re-checked once per pumped frame for up
    /// to this many frames: passes the moment a row matches, otherwise fails
    /// with the same diagnostics once the budget runs out.
    WaitRow(u32, String),
    /// Like [`Step::WaitRow`], over `crate::observe::snapshot(..).place_status`.
    WaitStatus(u32, String),
    /// Like [`Step::WaitRow`], satisfied once the named path exists and is
    /// non-empty — cross-process sequencing through a shared exchange dir.
    WaitFile(u32, String),
    /// Like [`Step::WaitRow`], over this session's
    /// `crate::observe::KnotDocumentFacts` entries, each formatted as
    /// "<status> <address>".
    WaitKnot(u32, String),
    /// Write the place observation facts (`crate::observe::place_record`),
    /// pretty-printed, to `<name>.json` in the capture directory.
    RecordPlace(String),
    /// Write a one-line marker file at an arbitrary path — the cross-process
    /// signal a scenario in another process waits on with `wait-file`.
    TouchFile(String),
    Log(String),
}

#[derive(Debug)]
pub enum EditKey {
    Enter,
    Escape,
    Tab,
    Backspace,
    Delete,
    Up,
    Down,
    Left,
    Right,
    Home,
    End,
    PageDown,
    PageUp,
    Space,
    Save,
    Find,
}

#[derive(Debug)]
pub enum CmpOp {
    Eq,
    Ge,
    Le,
}

/// Parse "`<x> <y>`" into a pair of f32 window coordinates.
fn parse_xy(s: &str) -> Option<(f32, f32)> {
    let mut it = s.split_whitespace();
    let x = it.next()?.parse().ok()?;
    let y = it.next()?.parse().ok()?;
    Some((x, y))
}

/// Replace every `${NAME}` in `line` with that process environment variable.
/// A name with no value set is a parse error (named by line), so a typo'd or
/// forgotten export fails loudly instead of leaving a literal `${NAME}` to be
/// matched against by accident.
pub(crate) fn expand_env(line: &str, line_no: usize) -> Result<String, String> {
    let mut out = String::with_capacity(line.len());
    let mut rest = line;
    while let Some(start) = rest.find("${") {
        let Some(end) = rest[start + 2..].find('}') else {
            out.push_str(&rest[..start + 2]);
            rest = &rest[start + 2..];
            continue;
        };
        let name = &rest[start + 2..start + 2 + end];
        let value = std::env::var(name)
            .map_err(|_| format!("line {line_no}: ${{{name}}} is not set"))?;
        out.push_str(&rest[..start]);
        out.push_str(&value);
        rest = &rest[start + 2 + end + 1..];
    }
    out.push_str(rest);
    Ok(out)
}

pub fn parse(body: &str) -> Result<Vec<Step>, String> {
    let mut steps = Vec::new();
    for (i, raw) in body.lines().enumerate() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let line = expand_env(line, i + 1)?;
        let line = line.as_str();
        let (verb, rest) = line.split_once(char::is_whitespace).unwrap_or((line, ""));
        let rest = rest.trim();
        let err = |msg: &str| Err(format!("line {}: {msg}: '{line}'", i + 1));
        steps.push(match verb {
            "open" if !rest.is_empty() => Step::Open(rest.to_string()),
            "omnibar" => match rest {
                "find" => Step::Omnibar { command: false },
                "actions" => Step::Omnibar { command: true },
                _ => return err("omnibar wants find|actions"),
            },
            "type" if !rest.is_empty() => Step::Type(rest.to_string()),
            "insert" if !rest.is_empty() => Step::Insert(rest.to_string()),
            "key" => match rest {
                "enter" => Step::Key(EditKey::Enter),
                "escape" => Step::Key(EditKey::Escape),
                "tab" => Step::Key(EditKey::Tab),
                "backspace" => Step::Key(EditKey::Backspace),
                "delete" => Step::Key(EditKey::Delete),
                "up" => Step::Key(EditKey::Up),
                "down" => Step::Key(EditKey::Down),
                "left" => Step::Key(EditKey::Left),
                "right" => Step::Key(EditKey::Right),
                "home" => Step::Key(EditKey::Home),
                "end" => Step::Key(EditKey::End),
                "pagedown" => Step::Key(EditKey::PageDown),
                "pageup" => Step::Key(EditKey::PageUp),
                "space" => Step::Key(EditKey::Space),
                "ctrl+s" => Step::Key(EditKey::Save),
                "ctrl+f" => Step::Key(EditKey::Find),
                _ => {
                    return err(
                        "key wants enter|escape|tab|backspace|delete|up|down|left|right|home|end|pagedown|pageup|space|ctrl+s|ctrl+f",
                    );
                }
            },
            "act" if !rest.is_empty() => Step::Act(rest.to_string()),
            "script" if !rest.is_empty() => Step::Script(rest.to_string()),
            "settle" => Step::Settle(if rest.is_empty() {
                20
            } else {
                rest.parse().map_err(|_| format!("line {}: bad settle count '{rest}'", i + 1))?
            }),
            "click-row" if !rest.is_empty() => Step::ClickRow(rest.to_string()),
            "drop-file" | "hover-file" => {
                let mut it = rest.splitn(3, char::is_whitespace);
                let x = it.next().and_then(|t| t.parse().ok());
                let y = it.next().and_then(|t| t.parse().ok());
                let path = it.next().map(str::trim).filter(|p| !p.is_empty());
                match (x, y, path) {
                    (Some(x), Some(y), Some(path)) if verb == "drop-file" => {
                        Step::DropFile(x, y, path.to_string())
                    }
                    (Some(x), Some(y), Some(path)) => {
                        Step::HoverFile(x, y, path.to_string())
                    }
                    _ => return err(&format!("{verb} wants '<x> <y> <path>'")),
                }
            }
            "drag-tab" => {
                // `drag-tab <a> out` releases OUTSIDE the workbench pane (on
                // the canvas): the tear-out trichotomy's branch arm.
                if let Some(from) = rest
                    .strip_suffix(" out")
                    .map(str::trim)
                    .filter(|f| !f.is_empty())
                {
                    Step::DragTabOut(from.to_string())
                } else {
                    let (from, onto) = rest
                        .split_once(" onto ")
                        .map(|(a, b)| (a.trim(), b.trim()))
                        .filter(|(a, b)| !a.is_empty() && !b.is_empty())
                        .ok_or_else(|| {
                            format!("line {}: drag-tab wants '<a> onto <b>': '{line}'", i + 1)
                        })?;
                    let (onto, edge) = match onto.split_once(" @ ") {
                        Some((b, e)) => {
                            let e = e.trim();
                            if !matches!(e, "left" | "right" | "top" | "bottom") {
                                return err("drag-tab edge wants left|right|top|bottom");
                            }
                            (b.trim(), Some(e.to_string()))
                        }
                        None => (onto, None),
                    };
                    Step::DragTab(from.to_string(), onto.to_string(), edge)
                }
            }
            "click-tab" if !rest.is_empty() => Step::ClickTab(rest.to_string()),
            "click-node" if !rest.is_empty() => Step::ClickNode(rest.to_string()),
            "drag" => {
                let nums: Vec<f32> = rest
                    .split_whitespace()
                    .filter_map(|t| t.parse().ok())
                    .collect();
                match nums[..] {
                    [x1, y1, x2, y2] => Step::Drag((x1, y1), (x2, y2)),
                    _ => return err("drag wants 'x1 y1 x2 y2'"),
                }
            }
            "click-at" => {
                let (x, y) = parse_xy(rest).ok_or_else(|| {
                    format!("line {}: click-at wants '<x> <y>': '{line}'", i + 1)
                })?;
                Step::Click(x, y)
            }
            "press-at" => {
                let (x, y) = parse_xy(rest).ok_or_else(|| {
                    format!("line {}: press-at wants '<x> <y>': '{line}'", i + 1)
                })?;
                Step::Press(x, y)
            }
            "release-at" => {
                let (x, y) = parse_xy(rest).ok_or_else(|| {
                    format!("line {}: release-at wants '<x> <y>': '{line}'", i + 1)
                })?;
                Step::Release(x, y)
            }
            "move-at" => {
                let (x, y) = parse_xy(rest).ok_or_else(|| {
                    format!("line {}: move-at wants '<x> <y>': '{line}'", i + 1)
                })?;
                Step::Move(x, y)
            }
            "touch-at" => {
                let mut fields = rest.split_whitespace();
                let id = fields.next().and_then(|value| value.parse().ok());
                let phase = match fields.next() {
                    Some("down") => Some(inker::PointerPhase::Down),
                    Some("move") => Some(inker::PointerPhase::Move),
                    Some("up") => Some(inker::PointerPhase::Up),
                    Some("cancel") => Some(inker::PointerPhase::Cancel),
                    _ => None,
                };
                let x = fields.next().and_then(|value| value.parse().ok());
                let y = fields.next().and_then(|value| value.parse().ok());
                let pressure = fields.next().map(str::parse).transpose().map_err(|_| {
                    format!("line {}: touch-at pressure must be a number: '{line}'", i + 1)
                })?;
                if fields.next().is_some() {
                    return err("touch-at has too many fields");
                }
                match (id, phase, x, y) {
                    (Some(id), Some(phase), Some(x), Some(y)) => {
                        Step::Touch(id, phase, x, y, pressure)
                    }
                    _ => {
                        return err(
                            "touch-at wants '<id> down|move|up|cancel <x> <y> [pressure]'",
                        );
                    }
                }
            }
            "right-click-at" => {
                let (x, y) = parse_xy(rest).ok_or_else(|| {
                    format!("line {}: right-click-at wants '<x> <y>': '{line}'", i + 1)
                })?;
                Step::RightClick(x, y)
            }
            "scroll" => {
                let mut it = rest.split_whitespace();
                let vals: Vec<f32> = it.by_ref().filter_map(|t| t.parse().ok()).collect();
                match vals.as_slice() {
                    // `scroll <x> <y> <dy>` (horizontal delta defaults to 0).
                    [x, y, dy] => Step::Scroll(*x, *y, 0.0, *dy),
                    [x, y, dx, dy] => Step::Scroll(*x, *y, *dx, *dy),
                    _ => return err("scroll wants '<x> <y> <dy>' or '<x> <y> <dx> <dy>'"),
                }
            }
            "scroll-reader" => {
                let mut fields = rest.split_whitespace();
                let role = fields.next();
                let dy = fields.next().and_then(|value| value.parse().ok());
                if fields.next().is_some() || role.is_none() || dy.is_none() {
                    return err("scroll-reader wants '<inset|workbench|tile> <dy>'");
                }
                Step::ScrollReader(role.unwrap().to_string(), dy.unwrap())
            }
            "divider" => {
                let ratio = rest
                    .parse()
                    .map_err(|_| format!("line {}: divider wants a ratio: '{line}'", i + 1))?;
                Step::Divider(ratio)
            }
            "capture" if !rest.is_empty() => Step::Capture(rest.to_string()),
            "capture-lens" if !rest.is_empty() => Step::CaptureLens(rest.to_string()),
            "record-reader-appearances" if !rest.is_empty() => {
                Step::RecordReaderAppearances(rest.to_string())
            }
            "record-idle" if !rest.is_empty() => Step::RecordIdle(rest.to_string()),
            "assert" => {
                let (what, arg) = rest.split_once(char::is_whitespace).unwrap_or((rest, ""));
                let arg = arg.trim();
                match what {
                    "omnibar" => match arg {
                        "open" => Step::AssertOmnibar(true),
                        "closed" => Step::AssertOmnibar(false),
                        _ => return err("assert omnibar wants open|closed"),
                    },
                    "omnibar-text" => Step::AssertText(arg.to_string()),
                    "event" if !arg.is_empty() => Step::AssertEvent(arg.to_string()),
                    "focused" if !arg.is_empty() => Step::AssertFocused(arg.to_string()),
                    "fetch" if !arg.is_empty() => Step::AssertBrowserFetch(arg.to_string()),
                    "link-preview" if !arg.is_empty() => Step::AssertLinkPreview(arg.to_string()),
                    "surface" if !arg.is_empty() => Step::AssertSurface(arg.to_string()),
                    "focus" if !arg.is_empty() => Step::AssertFocus(arg.to_string()),
                    "pane" if !arg.is_empty() => Step::AssertPane(arg.to_string()),
                    "maximized" => Step::AssertMaximized(true),
                    "not-maximized" => Step::AssertMaximized(false),
                    "scrolled" => match arg {
                        "moved" => Step::AssertScrolled(true),
                        "still" => Step::AssertScrolled(false),
                        _ => return err("assert scrolled wants moved|still"),
                    },
                    "row" if !arg.is_empty() => Step::AssertRow(arg.to_string()),
                    "no-row" if !arg.is_empty() => Step::AssertNoRow(arg.to_string()),
                    "tab" if !arg.is_empty() => Step::AssertTab(arg.to_string()),
                    "a11y" if !arg.is_empty() => Step::AssertA11y(arg.to_string()),
                    "lens-pane" if !arg.is_empty() => Step::AssertLensPane(arg.to_string()),
                    "lens-surface" if !arg.is_empty() => {
                        Step::AssertLensSurface(arg.to_string())
                    }
                    "no-pane" if !arg.is_empty() => Step::AssertNoPane(arg.to_string()),
                    "no-lens-pane" if !arg.is_empty() => {
                        Step::AssertNoLensPane(arg.to_string())
                    }
                    "no-surface" if !arg.is_empty() => Step::AssertNoSurface(arg.to_string()),
                    "reader-role" if !arg.is_empty() => Step::AssertReaderRole(arg.to_string()),
                    "reader-viewport" if !arg.is_empty() => {
                        Step::AssertReaderViewport(arg.to_string())
                    }
                    "reader-scroll" => {
                        let mut fields = arg.split_whitespace();
                        let role = fields.next();
                        let op = fields.next();
                        let amount = fields.next().and_then(|value| value.parse().ok());
                        if fields.next().is_some() || role.is_none() || op.is_none() || amount.is_none() {
                            return err("assert reader-scroll wants '<role> ==|>=|<= <px>'");
                        }
                        let op = match op.unwrap() {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert reader-scroll op wants ==|>=|<="),
                        };
                        Step::AssertReaderScroll(role.unwrap().to_string(), op, amount.unwrap())
                    }
                    "content-sessions-idle" if arg.is_empty() => Step::AssertContentSessionsIdle,
                    "content-ready" if arg.is_empty() => Step::AssertContentReady,
                    "reader-appearances" | "reader-sources" => {
                        let (op, n) = arg.split_once(char::is_whitespace).ok_or_else(|| {
                            format!("line {}: assert {what} wants '<op> <n>'", i + 1)
                        })?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert reader count op wants ==|>=|<="),
                        };
                        let n = n.trim().parse().map_err(|_| {
                            format!("line {}: bad {what} count", i + 1)
                        })?;
                        if what == "reader-appearances" {
                            Step::AssertReaderAppearances(op, n)
                        } else {
                            Step::AssertReaderSources(op, n)
                        }
                    }
                    "windows" | "sessions" | "nodes" | "overlaps" => {
                        let (op, n) = arg.split_once(char::is_whitespace).ok_or_else(|| {
                            format!("line {}: assert {what} wants '<op> <n>'", i + 1)
                        })?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert count op wants ==|>=|<="),
                        };
                        let n = n
                            .trim()
                            .parse()
                            .map_err(|_| format!("line {}: bad {what} count", i + 1))?;
                        match what {
                            "overlaps" => Step::AssertOverlaps(op, n),
                            "sessions" => Step::AssertSessions(op, n),
                            "nodes" => Step::AssertNodes(op, n),
                            _ => Step::AssertWindows(op, n),
                        }
                    }
                    "session" if !arg.is_empty() => Step::AssertSession(arg.to_string()),
                    "wb-cell" if !arg.is_empty() => Step::AssertWbCell(arg.to_string()),
                    "wb-cells" => {
                        let (op, n) = arg
                            .split_once(char::is_whitespace)
                            .ok_or_else(|| format!("line {}: assert wb-cells wants '<op> <n>'", i + 1))?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert wb-cells op wants ==|>=|<="),
                        };
                        let n = n
                            .trim()
                            .parse()
                            .map_err(|_| format!("line {}: bad wb-cells count", i + 1))?;
                        Step::AssertWbCells(op, n)
                    }
                    "wb-fraction" => {
                        let (op, f) = arg
                            .split_once(char::is_whitespace)
                            .ok_or_else(|| format!("line {}: assert wb-fraction wants '<op> <f>'", i + 1))?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert wb-fraction op wants ==|>=|<="),
                        };
                        let f = f
                            .trim()
                            .parse()
                            .map_err(|_| format!("line {}: bad wb-fraction", i + 1))?;
                        Step::AssertWbFraction(op, f)
                    }
                    "ratio" | "active-ratio" => {
                        let (op, n) = arg
                            .split_once(char::is_whitespace)
                            .ok_or_else(|| format!("line {}: assert ratio wants '<op> <r>'", i + 1))?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert ratio op wants ==|>=|<="),
                        };
                        let n = n
                            .trim()
                            .parse()
                            .map_err(|_| format!("line {}: bad ratio", i + 1))?;
                        if what == "active-ratio" {
                            Step::AssertActiveRatio(op, n)
                        } else {
                            Step::AssertRatio(op, n)
                        }
                    }
                    "physics" => match arg {
                        "running" => Step::AssertPhysicsRunning(true),
                        "paused" => Step::AssertPhysicsRunning(false),
                        _ => return err("assert physics wants running|paused"),
                    },
                    "energy" => {
                        let (op, n) = arg.split_once(char::is_whitespace).ok_or_else(|| {
                            format!("line {}: assert energy wants '<op> <n>'", i + 1)
                        })?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert energy op wants ==|>=|<="),
                        };
                        let n = n
                            .trim()
                            .parse()
                            .map_err(|_| format!("line {}: bad energy", i + 1))?;
                        Step::AssertEnergy(op, n)
                    }
                    "suggestions" => {
                        let (op, n) = arg
                            .split_once(char::is_whitespace)
                            .ok_or_else(|| format!("line {}: assert suggestions wants '<op> <n>'", i + 1))?;
                        let op = match op {
                            "==" => CmpOp::Eq,
                            ">=" => CmpOp::Ge,
                            "<=" => CmpOp::Le,
                            _ => return err("assert suggestions op wants ==|>=|<="),
                        };
                        let n = n
                            .trim()
                            .parse()
                            .map_err(|_| format!("line {}: bad suggestion count", i + 1))?;
                        Step::AssertSuggestions(op, n)
                    }
                    "visible" => Step::AssertVisible,
                    "content-live" => Step::AssertContentLive,
                    _ => return err("unknown assert"),
                }
            }
            "wait-row" | "wait-status" | "wait-file" | "wait-knot" => {
                let (frames, arg) = rest.split_once(char::is_whitespace).ok_or_else(|| {
                    format!("line {}: {verb} wants '<frames> <substr>'", i + 1)
                })?;
                let frames: u32 = frames.trim().parse().map_err(|_| {
                    format!("line {}: bad {verb} frame count '{frames}'", i + 1)
                })?;
                let arg = arg.trim();
                if arg.is_empty() {
                    return err(&format!("{verb} wants '<frames> <substr>'"));
                }
                match verb {
                    "wait-row" => Step::WaitRow(frames, arg.to_string()),
                    "wait-status" => Step::WaitStatus(frames, arg.to_string()),
                    "wait-file" => Step::WaitFile(frames, arg.to_string()),
                    _ => Step::WaitKnot(frames, arg.to_string()),
                }
            }
            "record-place" if !rest.is_empty() => Step::RecordPlace(rest.to_string()),
            "touch" if !rest.is_empty() => Step::TouchFile(rest.to_string()),
            "log" => Step::Log(rest.to_string()),
            _ => return err("unknown verb"),
        });
    }
    Ok(steps)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_errors_name_their_line() {
        let err = parse(
            "open mere://x
frobnicate
",
        )
        .unwrap_err();
        assert!(err.contains("line 2"), "{err}");
    }

    #[test]
    fn pointer_move_is_a_distinct_scenario_step() {
        let steps = parse("move-at 310 303").unwrap();
        let [Step::Move(x, y)] = steps.as_slice() else {
            panic!("move-at did not parse as a pointer move");
        };
        assert_eq!((*x, *y), (310.0, 303.0));
    }

    #[test]
    fn browser_receipt_assertions_are_typed_steps() {
        let steps = parse("assert fetch stopped\nassert link-preview /inside").unwrap();
        assert!(matches!(
            steps.as_slice(),
            [Step::AssertBrowserFetch(fetch), Step::AssertLinkPreview(link)]
                if fetch == "stopped" && link == "/inside"
        ));
    }

    #[test]
    fn file_hover_and_drop_are_distinct_ui_turns() {
        let steps = parse(
            "hover-file 350 280 receipt.txt
drop-file 350 280 receipt.txt",
        )
        .unwrap();
        assert!(
            matches!(steps[0], Step::HoverFile(350.0, 280.0, ref path) if path == "receipt.txt")
        );
        assert!(
            matches!(steps[1], Step::DropFile(350.0, 280.0, ref path) if path == "receipt.txt")
        );
    }

    #[test]
    fn save_chord_is_one_focus_routed_key_step() {
        let steps = parse("key ctrl+s").unwrap();
        assert!(matches!(steps.as_slice(), [Step::Key(EditKey::Save)]));
    }

    #[test]
    fn find_chord_is_one_focus_routed_key_step() {
        let steps = parse("key ctrl+f").unwrap();
        assert!(matches!(steps.as_slice(), [Step::Key(EditKey::Find)]));
    }

    #[test]
    fn tab_is_a_focus_routed_key_step() {
        let steps = parse("key tab").unwrap();
        assert!(matches!(steps.as_slice(), [Step::Key(EditKey::Tab)]));
    }

    #[test]
    fn wait_row_wait_status_wait_file_are_typed_steps() {
        let steps = parse(
            "wait-row 300 hello\nwait-status 60 Local rendezvous\nwait-file 3000 C:\\t\\exchange\\demo.place-card.json",
        )
        .unwrap();
        assert!(matches!(
            steps.as_slice(),
            [Step::WaitRow(300, row), Step::WaitStatus(60, status), Step::WaitFile(3000, path)]
                if row == "hello"
                && status == "Local rendezvous"
                && path == "C:\\t\\exchange\\demo.place-card.json"
        ));
    }

    #[test]
    fn wait_knot_is_a_typed_step() {
        let steps = parse("wait-knot 600 visiting knot://abcd/field.knot").unwrap();
        assert!(matches!(
            steps.as_slice(),
            [Step::WaitKnot(600, substr)] if substr == "visiting knot://abcd/field.knot"
        ));
    }

    #[test]
    fn record_place_is_a_typed_step() {
        let steps = parse("record-place founder").unwrap();
        assert!(matches!(steps.as_slice(), [Step::RecordPlace(name)] if name == "founder"));
    }

    #[test]
    fn touch_is_a_typed_step() {
        let steps = parse("touch C:\\t\\exchange\\joiner.stopped").unwrap();
        assert!(matches!(
            steps.as_slice(),
            [Step::TouchFile(path)] if path == "C:\\t\\exchange\\joiner.stopped"
        ));
    }

    #[test]
    fn env_substitution_expands_at_parse_time_backslashes_and_colons_intact() {
        // SAFETY: test-local env var, no other test in this process reads it.
        unsafe { std::env::set_var("TURNSTONE_TEST_EXCHANGE", "C:\\t\\exchange") };
        let steps = parse("type ${TURNSTONE_TEST_EXCHANGE}\\demo.place-card.json").unwrap();
        unsafe { std::env::remove_var("TURNSTONE_TEST_EXCHANGE") };
        assert!(matches!(
            steps.as_slice(),
            [Step::Type(text)] if text == "C:\\t\\exchange\\demo.place-card.json"
        ));
    }

    #[test]
    fn env_substitution_names_the_missing_variable_and_line() {
        let err = parse("wait-file 60 ${TURNSTONE_TEST_DOES_NOT_EXIST}\\card.json").unwrap_err();
        assert!(err.contains("line 1"), "{err}");
        assert!(err.contains("TURNSTONE_TEST_DOES_NOT_EXIST"), "{err}");
    }

    #[test]
    fn type_preserves_backslashes_and_colons_unchanged() {
        let steps = parse("type C:\\t\\exchange\\demo.place-card.json").unwrap();
        assert!(matches!(
            steps.as_slice(),
            [Step::Type(text)] if text == "C:\\t\\exchange\\demo.place-card.json"
        ));
    }

    #[test]
    fn idle_diagnostics_and_document_idle_are_typed_steps() {
        let steps = parse("record-idle after-fetch\nassert content-sessions-idle\nassert content-ready").unwrap();
        assert!(matches!(
            steps.as_slice(),
            [Step::RecordIdle(name), Step::AssertContentSessionsIdle, Step::AssertContentReady] if name == "after-fetch"
        ));
    }
}
