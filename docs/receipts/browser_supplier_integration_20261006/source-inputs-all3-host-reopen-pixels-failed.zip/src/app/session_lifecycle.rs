// Copyright 2026 Mark Alan Boykin
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0

//! Session lifecycle: boot, mint, adopt, fork, trash.
//!
//! Adopting is the load half of boot AND the whole of a switch, so both go
//! through one path: swap the graph in place, re-dress it from the facet
//! store, rebuild the participant runtime, and reopen the session's own windows.
//! A session owns its arrangement, so its lens spaces travel with it.

use std::path::PathBuf;

use mere::canvas::Canvas;
use uuid::Uuid;

use crate::action::Effect;
use crate::content::ContentStates;
use crate::observe::AppEvent;
use crate::panes::{FrisketLayout, GraphId, PaneContent, SessionId};
use crate::session;
use crate::surface::FocusTarget;
use crate::ui::OmnibarState;

use super::App;

impl App {
    /// Boot the app state (rung 6's second half: multi-session): load the
    /// manifest set, migrate the flat single-session layout if this profile
    /// predates `sessions/`, pick the session to open (recorded current,
    /// else most recent, else mint one), adopt it wholesale, then layer the
    /// launch address or the first-run sample graph on top. Returns the
    /// state plus the boot effects.
    pub fn boot(address: Option<&str>) -> (Self, Vec<Effect>) {
        let data_root = session::default_turnstone_root();
        let _ = std::fs::create_dir_all(&data_root);
        // Identity moved to the family-shared root. Turnstone held the personas
        // before the split, so it is the one that has to hand them over, and it
        // does so on first boot rather than as a migration step someone has to
        // remember to run.
        let shared = pandect::shared_root::shared_root();
        match pandect::shared_root::adopt_legacy_identity(&shared, &data_root) {
            Ok(true) => eprintln!("[turnstone] adopted this device's identity into {shared:?}"),
            Ok(false) => {}
            Err(error) => eprintln!("[turnstone] could not adopt the legacy identity: {error}"),
        }
        // The attributed journal + its capture hook (participant gate B1):
        // every mutation that flows through apply_graph_delta records here
        // under the current author.
        let (journal, hook) = mere::kernel::graph::journal_capture_hook();
        mere::kernel::graph::set_captured_delta_hook(Some(hook));
        let mut sessions = session::load_manifests(&data_root);
        // Pre-overmap manifests minted nil root_graph_ids; the container id
        // must be real (scene.* facet key + overmap identity), so heal at boot.
        session::heal_nil_graph_ids(&mut sessions);
        let migrated = session::migrate_flat_layout(&data_root, &mut sessions);
        let picked = migrated.or_else(|| session::pick_session(&data_root, &sessions));
        let (session_id, minted) = match picked {
            Some(id) => (id, false),
            None => (Self::mint_session(&data_root, &mut sessions), true),
        };
        let initial_graph = sessions
            .get(session_id)
            .map(|manifest| manifest.root_graph_id)
            .unwrap_or_else(GraphId::nil);
        let identity =
            crate::identity::load_or_create_root(&data_root, &crate::identity::default_vault_dir());
        let root = identity::IdentityProvider::master_public_key(identity.as_ref()).to_bytes();
        let gemini_identities = crate::gemini_identity::GeminiIdentityBindings::load(&data_root);
        let mut app = Self {
            watches: servitor::WatchTable::new(),
            app_watches: servitor::WatchTable::new(),
            events_seen: 0,
            events_base: 0,
            draining: false,
            time_watches: servitor::TimeWatchTable::new(),
            deadbands: servitor::DeadbandTable::new(),
            now_ms: None,
            behavior_cursor: 0,
            cascade_budget: servitor::cascade::CascadeBudget::DEFAULT.rounds(),
            graph_runtimes: super::GraphRuntimePool::new(
                initial_graph,
                Some(session_id),
                Canvas::new(),
            ),
            graph_views: super::GraphPaneViews::default(),
            forme_runtimes: super::FormeRuntimePool::default(),
            pane_context: crate::panes::ContextIndex::default(),
            omnibar: OmnibarState::default(),
            document_find: crate::document_find::DocumentFindState::default(),
            user_agent_decision: crate::user_agent_decision::UserAgentDecisionState::default(),
            frame_timings: crate::frame_timing::FrameTimings::default(),
            diagnostic_inspection: None,
            shell: crate::shell_services::ShellServices::default(),
            data_root,
            sessions,
            session_id,
            content: ContentStates::default(),
            engine_inventory: Vec::new(),
            feeds: crate::feed::FeedSubscriptions::default(),
            redshank: crate::redshank_host::RedshankHost::default(),
            redshank_members: std::collections::BTreeMap::new(),
            place: crate::place::PlaceState::default(),
            pending_place_artifact: None,
            next_place_generation: 0,
            next_place_request: 0,
            next_smolweb_submission: 0,
            active_smolweb_submission: None,
            micron_submission_sources: std::collections::HashMap::new(),
            focus: FocusTarget::Graph(crate::panes::PaneId(0)),
            link_preview: None,
            frisket: FrisketLayout::default(),
            history: chrome::nav::History::new(String::new()),
            active_pane: None,
            browser: pandect::browser_node_state::BrowserNodeStates::new(),
            physics_damping: pandect::DEFAULT_PHYSICS_DAMPING,
            maximized: None,
            window_count: 1,
            viewport: super::DEFAULT_VIEWPORT,
            lenses: Vec::new(),
            primary_blueprint: None,
            lens_blueprints: Vec::new(),
            roster_tab: 0,
            removed: Vec::new(),
            trash: Vec::new(),
            recall: Vec::new(),
            recall_query: String::new(),
            pending_install: None,
            denizens: crate::denizen::Denizens::new(root),
            resident_runs: crate::resident_runs::ResidentRuns::default(),
            resident_run_error: None,
            resident_run_effect_policy: crate::resident_runs::ExternalEffectPolicy::default(),
            resident_run_limits: servitor::RunLimits { decisions: crate::denizen::RUN_BUDGET as u64, tool_calls: 0, tokens: 0, elapsed_ms: 30_000, consecutive_failures: 1 },
            resident_run_storage_limits: crate::resident_runs::StorageLimits::default(),
            gemini_identities,
            identity,
            journal,
            next_pane_id: 1,
            events: Vec::new(),
            knot_documents: Vec::new(),
        };
        let mut effects = app.adopt_session(session_id);
        if let Some(url) = address {
            app.apply_launch_address(url, &mut effects);
        } else if minted && app.graph_runtimes.graph().nodes().count() == 0 {
            // A bare FIRST launch: the sample graph, with the omnibar open by
            // itself so the app is discoverable without documentation. A bare
            // relaunch restores the canvas quietly (Ctrl+L / Ctrl+K summon).
            tracing::info!("no session graph; starting on the sample graph");
            *app.graph_runtimes.active_canvas_mut() = Canvas::with_sample_graph();
            app.omnibar.open = true;
            let context = app.fallback_shell_context();
            app.shell.begin_omnibar(context);
            app.focus = FocusTarget::Chrome;
            app.recompute_omnibar_suggestions();
        }
        (app, effects)
    }

    /// Layer a command-line address over restored state. Kept separate from
    /// credential and profile bootstrapping so its effect ordering is covered
    /// without touching a person's profile during tests.
    pub(super) fn apply_launch_address(&mut self, url: &str, effects: &mut Vec<Effect>) {
        // The launch address is a pane-facing visit just like an omnibar
        // address. Saving it only on Canvas would be erased on the first pane
        // render when its local selection is restored.
        let pane = self.default_graph_pane();
        let key = self
            .with_graph_pane(pane, |canvas| canvas.visit(url))
            .expect("the default graph pane must resolve during boot");
        if crate::browse::is_fetchable(url)
            && let Some(node) = self.graph_runtimes.graph().get_node(key).map(|n| n.id)
        {
            // A restored content-on node already has a SpawnContent effect
            // from adopt_session. The fetch must precede that spawn so the
            // shell records one request before it decides whether a body is
            // pending. Appending it would start a request in SpawnContent,
            // then immediately supersede it with this launch request.
            let fetch = self.fetch_page_effect(node, url.to_string(), url.to_string());
            if let Some(index) = effects.iter().position(|effect| {
                matches!(effect, Effect::SpawnContent { node: actual, url: actual_url }
                    if *actual == node && actual_url == url)
            }) {
                effects.insert(index, fetch);
            } else {
                effects.push(fetch);
            }
        }
    }

    /// Mint a fresh session: a new manifest under `sessions/<id>/`, written
    /// through the store. Returns the id.
    pub(super) fn mint_session(
        data_root: &std::path::Path,
        sessions: &mut pandect::ManifestStore,
    ) -> crate::panes::SessionId {
        let id = crate::panes::SessionId::new();
        // A REAL GraphId from birth: the root graph is the session's container
        // node (the one-node model), so its id keys the scene.* facets and is
        // the session's identity in the overmap. (Pre-overmap sessions minted
        // nil; `session::heal_nil_graph_ids` repairs those at boot.)
        let mut manifest = pandect::GraphSessionManifest::new(id, GraphId::new());
        manifest.storage_path = Some(session::session_dir(data_root, id));
        sessions.insert(manifest);
        if let Err(err) = sessions.flush_dirty() {
            tracing::warn!(%err, "failed to write the new session's manifest");
        }
        id
    }

    /// The live session's directory — where every save and load targets.
    pub fn session_dir(&self) -> PathBuf {
        session::session_dir(&self.data_root, self.session_id)
    }

    /// Move `closing`'s whole directory to the manifest trash and refresh the
    /// removed-sessions cache (overmap O3). The shell calls this AFTER
    /// releasing the bin store (open files block the rename on Windows) and
    /// BEFORE adopting the next session. Returns whether the trash move ran.
    pub fn apply_trash(&mut self, closing: crate::panes::SessionId) -> bool {
        match self.sessions.move_to_trash(closing) {
            Ok(true) => {
                self.trash = self.sessions.list_trash();
                self.events.push(AppEvent::SessionClosed);
                true
            }
            Ok(false) => {
                tracing::warn!(session = %closing.as_uuid(), "close: nothing to trash");
                false
            }
            Err(err) => {
                tracing::warn!(%err, "failed to trash the closed session");
                false
            }
        }
    }

    /// Fork (tear-out G4-R R2): snapshot the connected component containing
    /// `seed` into a freshly minted session — new `SessionId` + real `GraphId`,
    /// a weak `parent_session` back-reference on the fork's manifest, the
    /// component's nodes + internal edges copied with `CopiedFrom` provenance,
    /// and the donor's per-node character carried by **facets** through the
    /// copy's id remap (`arrangement.*` layout, `web.*` browser state, foreign
    /// namespaces) plus the container's `scene.*`. Persists the fork's
    /// `graph.json` + `facets.json`, then returns the switch effect — v0 opens
    /// by session-switch (the shell saves the departing donor first, as every
    /// switch does); overmap navigation replaces that when it lands. Donor
    /// untouched; the two are independent thereafter. Returns no effects if
    /// `seed` names no node.
    pub fn fork_session_from(&mut self, seed: uuid::Uuid) -> Vec<Effect> {
        if self.graph_runtimes.graph().get_node_by_id(seed).is_none() {
            return Vec::new();
        }
        // Admission state is session-owned. A malformed existing sidecar must
        // stop the fork before any new session is minted; treating it as an
        // empty/default state would silently turn paused or revoked residents
        // into fresh active bindings in the child.
        let admission_path = crate::resident_admission::path(&self.session_dir());
        let donor_admissions = match admission_path.try_exists() {
            Ok(false) => None,
            Ok(true) => match crate::resident_admission::load(&self.session_dir()) {
                Ok(state) => Some(state),
                Err(error) => {
                    tracing::warn!(%error, "refusing to fork with malformed resident admission state");
                    return Vec::new();
                }
            },
            Err(error) => {
                tracing::warn!(%error, "refusing to fork because resident admission state cannot be inspected");
                return Vec::new();
            }
        };
        // The carry must read the moment, not the last save.
        self.refresh_browser_states();
        self.refresh_facets();

        // The kernel half: component copy with the id remap for the carry.
        let donor_graph_label = self.container_id().map(|c| c.to_string());
        let mut fork_graph = mere::kernel::graph::Graph::new();
        let copy =
            fork_graph.copy_component_from(self.graph_runtimes.graph(), seed, donor_graph_label);
        if copy.new_keys.is_empty() {
            return Vec::new();
        }

        // The world-carry: a donor node bearing a nested graph forks with a
        // REAL copy of its world. The component copy deliberately drops
        // `nested` (two live nodes must never share one world file); here the
        // fork re-bears each carried world directly (`bear_nested`, no delta
        // spine — the fork graph has no journal yet) and the world files copy
        // below once the fork's session dir exists.
        let mut carried_worlds: Vec<String> = Vec::new();
        for (donor_id, minted_id) in &copy.id_remap {
            let Some(log) = self
                .graph_runtimes
                .graph()
                .get_node_key_by_id(*donor_id)
                .and_then(|key| self.graph_runtimes.graph().get_node(key))
                .and_then(|node| node.nested.clone())
            else {
                continue;
            };
            if let Some(key) = fork_graph.get_node_key_by_id(*minted_id) {
                let _ = fork_graph.bear_nested(key, Some(log.clone()));
                carried_worlds.push(log.as_str().to_string());
            }
        }

        // The facet-carry: whole per-node records through the remap, scene
        // settings donor-container -> fork-container.
        let fork_graph_id = GraphId::new();
        let mut fork_facets = pandect::NodeFacetStore::new();
        pandect::copy_node_facets(
            self.graph_runtimes.facets(),
            &mut fork_facets,
            &copy.id_remap,
        );
        if let Some(donor_container) = self.container_id() {
            pandect::copy_scene_facets(
                self.graph_runtimes.facets(),
                &mut fork_facets,
                donor_container,
                *fork_graph_id.as_uuid(),
            );
        }
        let derivation_facet =
            chartulary::FacetId::new(mere::kernel::graph::node_facets::PROVENANCE_DERIVATIONS);
        let copied_derivations = copy
            .id_remap
            .iter()
            .filter_map(|(_, minted)| {
                fork_graph
                    .facets()
                    .get(minted, &derivation_facet)
                    .cloned()
                    .map(|value| (*minted, value))
            })
            .collect::<Vec<_>>();
        fork_graph.overlay_facets(fork_facets);
        let import_facet =
            chartulary::FacetId::new(mere::kernel::graph::node_facets::PROVENANCE_IMPORT);
        for (_, minted) in &copy.id_remap {
            fork_graph.facets_mut().remove(minted, &import_facet);
        }
        for (minted, value) in copied_derivations {
            fork_graph
                .facets_mut()
                .set(
                    minted,
                    derivation_facet.clone(),
                    value,
                    &chartulary::AcceptAll,
                )
                .expect("AcceptAll cannot reject copied derivation");
        }

        // Carry only admission records for members that actually crossed the
        // component boundary. The member UUID and ResidentId both change;
        // subject, body revision, lifecycle, generation, and skipped-wake
        // count remain the resident's durable state.
        let fork_admissions = donor_admissions.as_ref().map(|donor| {
            let mut fork = crate::resident_admission::ResidentAdmissions::default();
            for (donor_id, minted_id) in &copy.id_remap {
                if let Some(mut record) = donor.get(*donor_id).cloned() {
                    record.binding.id = crate::resident_admission::resident_id(*minted_id);
                    fork.insert(*minted_id, record);
                }
            }
            fork
        });

        // Mint the fork's session: manifest with the parent back-reference,
        // then its on-disk state, so the switch below adopts a real session.
        let fork_id = crate::panes::SessionId::new();
        let fork_dir = session::session_dir(&self.data_root, fork_id);
        if let Some(admissions) = &fork_admissions
            && let Err(error) = crate::resident_admission::save(&fork_dir, admissions)
        {
            tracing::warn!(%error, "refusing to fork because resident admission state could not be preserved");
            return Vec::new();
        }
        let mut manifest = pandect::GraphSessionManifest::new(fork_id, fork_graph_id);
        manifest.storage_path = Some(session::session_dir(&self.data_root, fork_id));
        manifest.parent_session = Some(self.session_id);
        self.sessions.insert(manifest);
        if let Err(err) = self.sessions.flush_dirty() {
            tracing::warn!(%err, "failed to write the fork session's manifest");
        }
        session::save_session_graph(&fork_dir, &fork_graph);
        session::save_node_facets(&fork_dir, fork_graph.facets());
        // Each carried world becomes the fork's own file: donor and fork
        // evolve their copies independently thereafter. A missing donor file
        // is fine — the resident rebuilds on an empty world, as always.
        let donor_dir = self.session_dir();
        for log_id in &carried_worlds {
            let from = crate::denizen::nested_log_path(&donor_dir, log_id);
            let to = crate::denizen::nested_log_path(&fork_dir, log_id);
            if !from.is_file() {
                continue;
            }
            let result = (|| -> std::io::Result<()> {
                if let Some(parent) = to.parent() {
                    std::fs::create_dir_all(parent)?;
                }
                std::fs::copy(&from, &to).map(|_| ())
            })();
            if let Err(err) = result {
                tracing::warn!(%err, log_id, "failed to carry a participant world into the fork");
            }
        }
        self.events.push(AppEvent::SessionForked);
        vec![Effect::SwitchSession { id: fork_id }]
    }

    /// A session's display label: the manifest's name when set, else the
    /// id's first 8 hex chars.
    pub fn session_label(&self, id: crate::panes::SessionId) -> String {
        self.sessions
            .get(id)
            .and_then(|m| m.display_name.clone())
            .unwrap_or_else(|| id.as_uuid().to_string()[..8].to_string())
    }

    /// Derive a human name for the live session from its graph: the display
    /// label of the most recently visited node (the page you were last on).
    /// `None` for an empty graph, so the uuid label stands until there is
    /// content to name the session after. The host stamps this into the
    /// manifest once, when `display_name` is still unset, so the switcher
    /// reads "Example Domain" instead of eight hex chars without churning as
    /// you keep browsing.
    pub(crate) fn derive_session_name(&self) -> Option<String> {
        let graph = self.graph_runtimes.graph();
        let recent = graph.recent_visited(1).into_iter().next()?;
        let (key, _) = graph.get_node_by_url(&recent.url)?;
        let label = graph.node_display_label(key);
        (!label.trim().is_empty()).then_some(label)
    }

    /// This profile's Personae root. The same root the worker evaluates
    /// authority for; read here so a card can name it without a round trip.
    pub(crate) fn personae_root(&self) -> [u8; 32] {
        use identity::IdentityProvider as _;
        self.identity.master_public_key().to_bytes()
    }

    /// Refuse one place gesture out loud, changing nothing.
    pub(crate) fn refuse_place(&mut self, reason: impl Into<String>) -> Vec<Effect> {
        self.events.push(AppEvent::PlaceRefused(reason.into()));
        vec![Effect::Redraw]
    }

    /// Put this bind's FULL rendezvous ticket(s) on the system clipboard.
    /// The status row elides the middle of a ~200-character ticket, so this is
    /// the only way the whole of it leaves the app. Multiple tickets join with
    /// newlines; the clipboard itself lives behind the shell.
    pub(crate) fn copy_local_rendezvous(&mut self) -> Vec<Effect> {
        let tickets = self.place.local_rendezvous().to_vec();
        if tickets.is_empty() {
            return self.refuse_place("no local rendezvous to copy");
        }
        self.events
            .push(AppEvent::PlaceRendezvousCopied(tickets.len()));
        vec![
            Effect::CopyText(tickets.join("\n")),
            Effect::Redraw,
        ]
    }

    /// Open one free-text place prompt, in the rename shape.
    ///
    /// The precondition is checked HERE rather than only at commit, so a
    /// prompt that could not possibly succeed never opens.
    pub(super) fn begin_place_prompt(&mut self, prompt: crate::ui::PlacePrompt) -> Vec<Effect> {
        use crate::ui::PlacePrompt;
        let joined = self.place.binding().is_some();
        match prompt {
            PlacePrompt::FoundPlace | PlacePrompt::OfferPrekey | PlacePrompt::Join if joined => {
                return self.refuse_place("leave this place before joining or founding another");
            },
            PlacePrompt::ExportCard
            | PlacePrompt::Invite
            | PlacePrompt::InviteReader
            | PlacePrompt::SendMessage
                if !joined =>
            {
                return self.refuse_place("this session is not in a place");
            },
            _ => {},
        }
        self.omnibar = OmnibarState {
            open: true,
            mode: crate::ui::OmnibarMode::Place(prompt),
            ..OmnibarState::default()
        };
        let target = self.fallback_shell_context();
        self.shell.begin_omnibar(target);
        self.focus = FocusTarget::Chrome;
        self.recompute_omnibar_suggestions();
        self.events.push(AppEvent::OmnibarOpened);
        vec![Effect::Redraw]
    }

    /// Found a place in this session. Claims no binding: `Joining` carries a
    /// generation and nothing else until the worker answers.
    pub fn found_place(&mut self, name: String) -> Vec<Effect> {
        if self.place.binding().is_some() {
            return self.refuse_place("leave this place before founding another");
        }
        let name = name.trim().to_string();
        if name.is_empty() {
            return self.refuse_place("a place needs a name");
        }
        self.next_place_generation = self.next_place_generation.wrapping_add(1);
        let generation = self.next_place_generation;
        self.place = crate::place::PlaceState::Joining { generation };
        vec![Effect::FoundPlace {
            session: self.session_id,
            generation,
            name,
        }]
    }

    /// Write this place's card. Contact metadata and public ids only.
    pub fn export_place_card(&mut self, path: String) -> Vec<Effect> {
        let Some(binding) = self.place.binding().cloned() else {
            return self.refuse_place("open a place before exporting its card");
        };
        let local_rendezvous = match &self.place {
            crate::place::PlaceState::Offline { snapshot, .. } => snapshot
                .sync
                .as_ref()
                .map(|sync| sync.local_rendezvous.clone())
                .unwrap_or_default(),
            _ => Vec::new(),
        };
        let card = crate::place::PlaceCardV1 {
            version: crate::place::PLACE_CARD_VERSION,
            binding,
            founder_root: crate::place::hex32(&self.personae_root()),
            rendezvous: local_rendezvous
                .into_iter()
                .map(|hint| crate::place::invite::RendezvousV1 {
                    carrier: crate::place::invite::P2PANDA_ENDPOINT_TICKET.into(),
                    hint,
                })
                .collect(),
        };
        match serde_json::to_vec_pretty(&card) {
            Ok(bytes) => vec![Effect::WritePlaceArtifact { path, bytes }],
            Err(error) => self.refuse_place(format!("encode place card: {error}")),
        }
    }

    /// Read a card, so a pre-key can be offered against the Moot it names.
    pub fn offer_place_prekey(&mut self, path: String) -> Vec<Effect> {
        if self.place.binding().is_some() {
            return self.refuse_place("leave this place before offering a pre-key elsewhere");
        }
        vec![Effect::ReadPlaceArtifact {
            path,
            kind: crate::action::PlaceArtifactKind::Card,
        }]
    }

    /// Publish this profile's group identity for the card's Moot.
    pub(crate) fn offer_place_prekey_for_card(
        &mut self,
        card: Box<crate::place::PlaceCardV1>,
        out: String,
    ) -> Vec<Effect> {
        if let Err(error) = card.validate() {
            return self.refuse_place(error);
        }
        self.next_place_generation = self.next_place_generation.wrapping_add(1);
        let generation = self.next_place_generation;
        self.pending_place_artifact = Some(super::PendingPlaceArtifact {
            generation,
            path: out,
            moot: card.binding.moot,
        });
        vec![Effect::OfferPlacePrekey {
            session: self.session_id,
            generation,
            moot: card.binding.moot.0,
        }]
    }

    /// Read a pre-key offer, so an invitation can be authored for it. The
    /// access travels with the read: the prompt that asked for the path is
    /// what decided whether this admits a writer or a reader.
    pub fn invite_to_place(
        &mut self,
        path: String,
        access: crate::place::PlaceInviteAccess,
        lifetime_ms: Option<u64>,
    ) -> Vec<Effect> {
        if self.place.binding().is_none() {
            return self.refuse_place("open a place before inviting anyone");
        }
        // Refused, not ignored: a lifetime the grant cannot carry is a mistake.
        if lifetime_ms.is_some() && access == crate::place::PlaceInviteAccess::Reader {
            return self.refuse_place("a reader invitation carries no grant to bound");
        }
        vec![Effect::ReadPlaceArtifact {
            path,
            kind: crate::action::PlaceArtifactKind::Prekey {
                access,
                lifetime_ms,
            },
        }]
    }

    pub(crate) fn invite_to_place_with_prekey(
        &mut self,
        prekey: Vec<u8>,
        out: String,
        access: crate::place::PlaceInviteAccess,
        lifetime_ms: Option<u64>,
    ) -> Vec<Effect> {
        let Some(binding) = self.place.binding().cloned() else {
            return self.refuse_place("open a place before inviting anyone");
        };
        let Some(generation) = self.place.generation() else {
            return self.refuse_place("open a place before inviting anyone");
        };
        self.pending_place_artifact = Some(super::PendingPlaceArtifact {
            generation,
            path: out,
            moot: binding.moot,
        });
        vec![Effect::InvitePlace {
            session: self.session_id,
            generation,
            prekey,
            access,
            lifetime_ms,
        }]
    }

    /// Revoke one member of the open place. The worker decides whether this
    /// profile may; the app only refuses when there is no place to ask.
    pub fn revoke_place_member(&mut self, member: [u8; 32]) -> Vec<Effect> {
        if !matches!(self.place, crate::place::PlaceState::Offline { .. }) {
            return self.refuse_place("open a place before revoking a member");
        }
        self.run_place_command(crate::place::worker::PlaceCommand::RevokeMember { member })
    }

    /// Read an invitation file, so the existing join path can admit it.
    pub fn join_place_file(&mut self, path: String) -> Vec<Effect> {
        if self.place.binding().is_some() {
            return self.refuse_place("leave this place before joining another");
        }
        vec![Effect::ReadPlaceArtifact {
            path,
            kind: crate::action::PlaceArtifactKind::Invite,
        }]
    }

    /// Ask the worker to admit `invite` into the current session.
    ///
    /// The app claims nothing while it waits. `Joining` carries a generation
    /// and no binding, because the envelope naming a place is not the same as
    /// the place having admitted this profile, and a refusal must leave the
    /// session exactly as personal as it was.
    pub fn join_place(&mut self, invite: Box<crate::place::invite::PlaceInviteV1>) -> Vec<Effect> {
        self.next_place_generation = self.next_place_generation.wrapping_add(1);
        let generation = self.next_place_generation;
        self.place = crate::place::PlaceState::Joining { generation };
        vec![Effect::JoinPlace {
            session: self.session_id,
            generation,
            invite,
        }]
    }

    /// Reopen admitted state and dial its saved contact hints on an explicit gesture.
    pub fn reconnect_place(&mut self) -> Vec<Effect> {
        // `binding()` reads `Left` as not joined, so a left session cannot
        // reconnect around its own mark; `rejoin_place` is its route back.
        let Some(binding) = self.place.binding().cloned() else {
            self.events.push(AppEvent::PlaceRefused(
                "join a place before reconnecting".into(),
            ));
            return vec![Effect::Redraw];
        };
        self.next_place_generation = self.next_place_generation.wrapping_add(1);
        let generation = self.next_place_generation;
        self.place = crate::place::PlaceState::Opening {
            binding: binding.clone(),
            generation,
        };
        vec![Effect::ReconnectPlace { session: self.session_id, generation, binding }]
    }

    /// Reconnect a locally left place: clear its left mark, then dial saved
    /// contact hints the same way `reconnect_place` does for a still-live
    /// one. Valid only from `PlaceState::Left`, and the only route out of
    /// it: `reconnect_place` reads `Left` as not joined.
    pub fn rejoin_place(&mut self) -> Vec<Effect> {
        let Some(binding) = self.place.left_binding().cloned() else {
            self.events.push(AppEvent::PlaceRefused(
                "this session did not leave a place to rejoin".into(),
            ));
            return vec![Effect::Redraw];
        };
        self.next_place_generation = self.next_place_generation.wrapping_add(1);
        let generation = self.next_place_generation;
        self.place = crate::place::PlaceState::Opening { binding: binding.clone(), generation };
        vec![
            Effect::ClearPlaceLeftMark { session: self.session_id },
            Effect::ReconnectPlace { session: self.session_id, generation, binding },
        ]
    }

    /// Request local departure. The shell releases the worker and marks this
    /// place locally left -- binding, rendezvous hints and every retained
    /// store stay in place, so `Rejoin` has what it needs -- before
    /// completing the transition.
    pub fn leave_place(&mut self) -> Vec<Effect> {
        let Some(generation) = self.place.generation() else {
            self.events.push(AppEvent::PlaceRefused(
                "this session is not in a place".into(),
            ));
            return vec![Effect::Redraw];
        };
        // Retained counts come from the Offline snapshot in hand right now;
        // any other prior state (Degraded, a retried leave) has no snapshot
        // to read, so the summary reads zero rather than guessing at what
        // the stores hold. Computed here, once, rather than recomputed in
        // `finish_leave_place`: the shell needs the same counts to write the
        // left mark, and `self.place` does not change while the effect is
        // in flight.
        let retained = match &self.place {
            crate::place::PlaceState::Offline { snapshot, .. } => crate::place::PlaceLeftSummary {
                graph_nodes: snapshot.graph.nodes,
                chat_messages: snapshot.chat.messages,
                members: snapshot.moot.members,
            },
            _ => crate::place::PlaceLeftSummary::default(),
        };
        vec![Effect::LeavePlace {
            session: self.session_id,
            generation,
            retained,
        }]
    }

    pub(crate) fn finish_leave_place(
        &mut self,
        session: SessionId,
        generation: u64,
        retained: crate::place::PlaceLeftSummary,
        result: Result<bool, String>,
    ) -> Vec<Effect> {
        if self.session_id != session || self.place.generation() != Some(generation) {
            return Vec::new();
        }
        match result {
            Ok(_) => {
                // A binding is what makes Left rejoinable; a leave from
                // Joining (admission never finished, so there was never one)
                // has nothing to remember and reads as Personal, as it
                // always has.
                self.place = match self.place.binding().cloned() {
                    Some(binding) => crate::place::PlaceState::Left { binding, retained },
                    None => crate::place::PlaceState::Personal,
                };
                vec![Effect::Redraw]
            }
            Err(error) => {
                let binding = self.place.binding().cloned();
                self.next_place_generation = self.next_place_generation.wrapping_add(1);
                let failed_generation = self.next_place_generation;
                if let Some(binding) = binding {
                    self.place = crate::place::PlaceState::Degraded {
                        binding,
                        generation: failed_generation,
                        error: error.clone(),
                    };
                } else {
                    self.place = crate::place::PlaceState::Failed {
                        error: error.clone(),
                    };
                }
                self.events
                    .push(AppEvent::PlaceRefused(format!("leaving place: {error}")));
                vec![Effect::Redraw]
            }
        }
    }

    /// Bring the shared graph's addresses into this session's Canvas.
    ///
    /// Additive by construction. The place decides what the PLACE holds, never
    /// what this person's canvas holds, so a node the person put there is
    /// never moved, relabelled, or removed by shared state converging; a
    /// shared node that leaves the place simply stops arriving here. The only
    /// mutation is minting what is missing, which is why this can run on every
    /// resync without accumulating damage.
    ///
    /// Returns how many nodes it minted, so a caller can tell "nothing new"
    /// from "nothing happened".
    pub fn reconcile_shared_graph(
        &mut self,
        shared: &crate::place::projection::SharedGraph,
    ) -> usize {
        let missing: Vec<String> = shared
            .addresses()
            .filter(|address| {
                self.graph_runtimes
                    .graph()
                    .get_node_by_url(address)
                    .is_none()
            })
            .map(str::to_string)
            .collect();
        // Selection is the person's, so restore it: `visit` selects what it
        // mints, and a background resync must not move the cursor.
        let selected = self.graph_runtimes.selected_members();
        for address in &missing {
            self.graph_runtimes.visit(address);
        }
        if !missing.is_empty() {
            for member in selected {
                self.graph_runtimes.select_member(member);
            }
        }
        missing.len()
    }

    /// The focused node's address, for sharing it into the place.
    pub fn focused_address(&self) -> Option<String> {
        let member = self.graph_runtimes.focused_member()?;
        let (_, node) = self.graph_runtimes.graph().get_node_by_id(member)?;
        let url = node.url().trim();
        (!url.is_empty()).then(|| url.to_string())
    }

    /// Lower one place command, if this session actually has an open place.
    ///
    /// Refused locally when there is no place rather than sent to a worker
    /// that would refuse it anyway: "you are not in a place" is a different
    /// answer from "the place refused you", and only one of them is about
    /// authority.
    pub fn run_place_command(
        &mut self,
        command: crate::place::worker::PlaceCommand,
    ) -> Vec<Effect> {
        let Some(generation) = self.place.generation() else {
            self.events.push(AppEvent::PlaceRefused(
                "this session is not in a place".into(),
            ));
            return vec![Effect::Redraw];
        };
        self.next_place_request = self.next_place_request.wrapping_add(1);
        vec![Effect::RunPlaceCommand {
            session: self.session_id,
            generation,
            request: self.next_place_request,
            command,
        }]
    }

    /// Ask the worker to re-fold what the lanes have drained in.
    pub fn resync_place(&mut self) -> Vec<Effect> {
        let Some(generation) = self.place.generation() else {
            return Vec::new();
        };
        vec![Effect::ResyncPlace {
            session: self.session_id,
            generation,
        }]
    }

    /// Ask the open place worker to remint captured search through one exact
    /// collection version. This is a local view choice and authors no Moot fact.
    pub fn set_place_collection(
        &mut self,
        selection: Option<crate::place::PlaceCollectionVersion>,
    ) -> Vec<Effect> {
        let Some(generation) = self.place.generation() else {
            self.events.push(AppEvent::PlaceRefused(
                "this session is not in a place".into(),
            ));
            return vec![Effect::Redraw];
        };
        vec![Effect::SetPlaceCollection {
            session: self.session_id,
            generation,
            selection,
        }]
    }

    /// Adopt `id`'s persisted state wholesale — the load half of a boot and
    /// the whole of a switch. Rebuilds canvas / panes / workbench / browser /
    /// content from `sessions/<id>/` (missing files start fresh), reseeds
    /// history and the focus restore, and returns the adoption's effects
    /// (content respawns + lens-window reopens). Session-scoped view state
    /// (omnibar, active pane, maximize) resets.
    pub fn adopt_session(&mut self, id: crate::panes::SessionId) -> Vec<Effect> {
        self.session_id = id;
        let graph = self
            .sessions
            .get(id)
            .map(|manifest| manifest.root_graph_id)
            .unwrap_or_else(GraphId::nil);
        self.graph_runtimes
            .activate_or_insert(graph, Some(id), Canvas::new());
        session::record_current_session(&self.data_root, id);
        if self.sessions.update(id, |m| m.touch()) {
            if let Err(err) = self.sessions.flush_dirty() {
                tracing::warn!(%err, "failed to touch the adopted session's manifest");
            }
        }
        let sdir = self.session_dir();
        // This is the sole recovery boundary. Do not reload this store around
        // nested `update` calls: the live table is what prevents overlap.
        self.resident_runs = crate::resident_runs::ResidentRuns::with_limits(self.resident_run_storage_limits);
        self.resident_run_error = None;
        match crate::resident_runs::load_or_empty_with_limits(&sdir, self.resident_run_storage_limits) {
            Ok(mut runs) => {
                let recovered = runs.validate_session(*id.as_uuid())
                    .and_then(|()| runs.mark_interrupted(crate::denizen::now_ms()))
                    .and_then(|()| crate::resident_runs::save(&sdir, &runs));
                match recovered {
                    Ok(()) => self.resident_runs = runs,
                    Err(error) => {
                        self.resident_run_error = Some(format!("cannot recover resident run state: {error}"));
                    }
                }
            }
            Err(error) => {
                self.resident_run_error = Some(error);
            }
        }
        let mut effects = Vec::new();
        self.next_place_generation = self.next_place_generation.wrapping_add(1);
        let place_generation = self.next_place_generation;
        // A shared session opens its private graph cache immediately while the
        // worker materializes the retained Gemot, Commons, chat, and group
        // state. The worker answer is accepted only for this generation.
        // A left mark beside the binding means this session must not open
        // lanes or reconnect on its own: the retained counts come from the
        // marker `leave` wrote, cheap to read and exactly what `Left`'s own
        // status row already shows, rather than opening the retained stores
        // here just to recompute them before the person has even asked to
        // rejoin. Read once, ahead of the binding match below, so a marker
        // read failure and a marker hit share one branch instead of reading
        // the file twice.
        let left_mark = session::load_place_left(&sdir);
        self.place = match session::load_place_binding(&sdir) {
            Ok(Some(binding)) if !matches!(left_mark, Ok(None)) => {
                effects.push(Effect::ClosePlace {
                    session: id,
                    generation: place_generation,
                });
                match left_mark {
                    Ok(Some(retained)) => crate::place::PlaceState::Left { binding, retained },
                    Err(error) => {
                        tracing::warn!(%error, "place-left mark failed to load");
                        crate::place::PlaceState::Failed { error: error.to_string() }
                    },
                    Ok(None) => unreachable!("guarded above"),
                }
            }
            Ok(Some(binding)) => {
                effects.push(Effect::OpenPlace {
                    session: id,
                    generation: place_generation,
                    binding: binding.clone(),
                });
                crate::place::PlaceState::Opening {
                    binding,
                    generation: place_generation,
                }
            }
            Ok(None) => {
                effects.push(Effect::ClosePlace {
                    session: id,
                    generation: place_generation,
                });
                crate::place::PlaceState::Personal
            }
            Err(error) => {
                tracing::warn!(%error, "place binding failed to load");
                effects.push(Effect::ClosePlace {
                    session: id,
                    generation: place_generation,
                });
                crate::place::PlaceState::Failed {
                    error: error.to_string(),
                }
            }
        };
        // The graph: restored, else fresh — swapped IN PLACE through the
        // canvas's own session-switch seam (mere's MG2 `set_graph`: physics
        // actor and node pool stay alive, every node parks at the origin and
        // halts; the saved layout is applied from the facet store next).
        self.graph_runtimes
            .set_graph(session::load_session_graph(&sdir).unwrap_or_default());
        self.feeds = crate::feed::FeedSubscriptions::load(&sdir);
        self.feeds.reconcile(self.graph_runtimes.graph());
        self.reconcile_feed_tags();
        // The listening model rides the session directory like the feeds do.
        // A session with no audio output still reopens its library, progress
        // and notes; only the runtime is absent.
        // The new session keeps the shell's output and fetch handle.
        self.redshank = self.redshank.reopen(&sdir);
        self.redshank_members.clear();
        self.reconcile_redshank_fields();
        if let Some(score) = session::load_projection_score(&sdir) {
            self.graph_runtimes.restore_projection_score(score);
        }
        // Restore the chosen arrangement beside the score it produced, so a
        // reopened session comes back to the view the user left rather than to
        // the surface default. Set through the runtimes directly: the app-level
        // arm clears the score for a non-Spiral strategy, which is right for a
        // fresh choice and wrong for a restore of the pair.
        if let Some(intent) = session::load_view_intent(&sdir) {
            self.graph_runtimes
                .set_layout_strategy(intent.layout_strategy);
            // The physics choice rides the same sidecar: sources first, so
            // the law's build reads them, then the overlays, then the law.
            // An unknown id (a newer catalog) falls back to the default
            // rather than failing the open. (Physics catalog — P2.)
            if let Some(source) = intent
                .physics_kind_source
                .as_deref()
                .and_then(mere::canvas::PhysicsKindSource::parse)
            {
                self.graph_runtimes.set_physics_kind_source(source);
            }
            if let Some(source) = intent
                .physics_mass_source
                .as_deref()
                .and_then(mere::canvas::PhysicsMassSource::parse)
            {
                self.graph_runtimes.set_physics_mass_source(source);
            }
            if let Some(source) = intent
                .physics_depth_source
                .as_deref()
                .and_then(mere::canvas::PhysicsDepthSource::parse)
            {
                self.graph_runtimes.set_physics_depth_source(source);
            }
            self.graph_runtimes.set_physics_overlays(
                intent
                    .physics_overlays
                    .iter()
                    .filter_map(|id| mere::canvas::PhysicsOverlay::parse(id))
                    .collect(),
            );
            if let Some(law) = intent
                .physics_law
                .as_deref()
                .and_then(mere::canvas::PhysicsLaw::parse)
            {
                self.graph_runtimes.set_physics_law(law);
            }
        }
        // Preview imagery lives out of the graph now. The first paint queues
        // only visible cache misses; the shell resolves those after the frame,
        // so adoption does not decode the entire session into memory.
        // The facet store (`facets.json`): pruned to the live graph's nodes
        // (a deleted node's facets go with it), then the arrangement.* family
        // re-dresses the canvas — the durable layout, since the graph itself
        // is position-free. A session with no facets keeps the origin park and
        // settles fresh on the first nudge. Order per the canvas seams:
        // positions seed first (halting physics), sprites before their hulls,
        // faces after sprites (so a switched-off sprite face stays switched).
        // The removed-sessions cache (overmap O3): derived from the manifest
        // trash, refreshed here and on close/recover.
        self.trash = self.sessions.list_trash();
        self.graph_runtimes
            .overlay_facets(session::load_node_facets(&sdir).unwrap_or_default());
        // A profile saved before the nil-GraphId heal keyed its scene.* facets
        // by the nil uuid; move them onto the healed container id once.
        if let Some(container) = self.container_id() {
            let nil = uuid::Uuid::nil();
            if container != nil && self.graph_runtimes.facets().facets_of(&nil).is_some() {
                let donor = self.graph_runtimes.facets().clone();
                pandect::copy_scene_facets(
                    &donor,
                    self.graph_runtimes.facets_mut(),
                    nil,
                    container,
                );
                self.graph_runtimes.facets_mut().remove_node(&nil);
            }
        }
        let mut present: std::collections::BTreeSet<uuid::Uuid> = self
            .graph_runtimes
            .graph()
            .nodes()
            .map(|(_, n)| n.id)
            .collect();
        // Keep the container's `scene.*` facets through the reconcile: the
        // container id is not a leaf graph node, so without this the prune
        // would sweep the scene settings away.
        if let Some(container) = self.container_id() {
            present.insert(container);
        }
        pandect::retain_present_nodes(self.graph_runtimes.facets_mut(), &present);
        match crate::content_classes::reconcile(&mut self.graph_runtimes) {
            Ok(changed) if changed > 0 => {
                tracing::info!(
                    changed,
                    "founded built-in content classes on restored nodes"
                );
                effects.push(Effect::SaveSession);
            }
            Ok(_) => {}
            Err(error) => tracing::warn!(%error, "content-class reconciliation failed"),
        }
        let positions = pandect::read_arrangement_positions(self.graph_runtimes.facets());
        self.graph_runtimes.seed_cartography(positions);
        // The participant runtime derives from the binding facets (agency) + the
        // graph's `Node.nested` pointers (structure) + the nested logs.
        self.pending_install = None;
        self.denizens = crate::denizen::rebuild(
            self.graph_runtimes.facets(),
            self.graph_runtimes.graph(),
            &sdir,
            self.identity.as_ref(),
        );
        // Residency came back; its standing subscriptions have to come with
        // it, or a behavior silently stops waking after a reload.
        (
            self.watches,
            self.app_watches,
            self.time_watches,
            self.deadbands,
        ) = crate::denizen::load_watches(&self.session_dir());
        // One-time heal for bindings written before the containment ruling:
        // move the world pointer onto the node (journaled through the spine)
        // and rewrite the facet without it.
        for (member, log_id) in std::mem::take(&mut self.denizens.legacy_heals) {
            let _ = self
                .graph_runtimes
                .set_node_nested_for(member, Some(mere::kernel::graph::LogId::new(log_id)));
            if let Some(binding) =
                pandect::read_denizen_binding(self.graph_runtimes.facets(), member)
            {
                pandect::write_denizen_binding(self.graph_runtimes.facets_mut(), member, &binding);
            }
        }
        // The scene's own view settings ride the `scene.*` container facets:
        // the sizing mode + metric and the physics damping re-open as saved.
        let scene = self
            .container_id()
            .map(|c| pandect::read_scene_facets(self.graph_runtimes.facets(), c))
            .unwrap_or_default();
        self.physics_damping = scene.physics_damping;
        self.graph_runtimes
            .set_physics_damping(scene.physics_damping);
        self.graph_runtimes
            .apply_cartography_importance_metric(&scene.importance_metric);
        let sizes = pandect::read_arrangement_sizes(self.graph_runtimes.facets());
        self.graph_runtimes.apply_cartography_sizing(
            sizes,
            scene.size_by_degree,
            scene.size_by_importance,
        );
        let sprites = pandect::read_arrangement_sprites(self.graph_runtimes.facets());
        self.graph_runtimes
            .apply_cartography_sprites(sprites.iter().map(|(id, uri)| (*id, uri.as_str())));
        let hulls = pandect::read_arrangement_sprite_hulls(self.graph_runtimes.facets());
        self.graph_runtimes.apply_cartography_sprite_hulls(hulls);
        let materials = pandect::read_arrangement_materials(self.graph_runtimes.facets());
        self.graph_runtimes.apply_cartography_materials(materials);
        let faces = pandect::read_arrangement_faces(self.graph_runtimes.facets());
        self.graph_runtimes
            .apply_cartography_faces(faces.iter().map(|(id, code)| (*id, code.as_str())));
        // Session-scoped view state resets.
        self.omnibar = OmnibarState::default();
        self.document_find = crate::document_find::DocumentFindState::default();
        self.user_agent_decision = crate::user_agent_decision::UserAgentDecisionState::default();
        self.focus = FocusTarget::Graph(self.default_graph_pane());
        self.active_pane = None;
        self.maximized = None;
        self.roster_tab = 0;
        // The pane layout, and the lens-window spaces: each live slot gets
        // its window reopened through the ordinary OpenWindow effect — the
        // same port a fresh tear-out uses, so a restored window is spawned
        // truth, not painted memory. The id ceiling spans EVERY space.
        self.frisket = session::load_frisket_layout(&sdir).unwrap_or_default();
        self.lenses = session::load_lens_spaces(&sdir);
        // A5's live bridge is intentionally not written into the legacy
        // frame sidecars. A session adopt therefore starts from those durable
        // Frisket payloads and re-promotes a space only on its next float.
        self.primary_blueprint = None;
        self.lens_blueprints = vec![None; self.lenses.len()];
        let valid_graphs = self
            .sessions
            .iter()
            .map(|(_, manifest)| manifest.root_graph_id)
            .collect();
        self.frisket.retag_graph_bound_invalid(&valid_graphs, graph);
        for lens in self.lenses.iter_mut().flatten() {
            lens.retag_graph_bound_invalid(&valid_graphs, graph);
        }
        self.index_pane_spaces();
        self.focus = FocusTarget::Graph(self.default_graph_pane());
        for (ordinal, space) in self.lenses.iter().enumerate() {
            if space.is_some() {
                effects.push(Effect::OpenWindow { ordinal });
            }
        }
        self.next_pane_id = self
            .frisket
            .iter_leaves()
            .map(|(id, _, _)| id.0)
            .chain(
                self.lenses
                    .iter()
                    .flatten()
                    .flat_map(|s| s.iter_leaves().map(|(id, _, _)| id.0).collect::<Vec<_>>()),
            )
            .max()
            .unwrap_or(0)
            + 1;
        // The legacy workbench sidecar belongs to this session's identity
        // forme. Other Forme runtimes are lazy and therefore cannot overwrite
        // this restored arrangement by merely appearing in another pane.
        let present = self
            .graph_runtimes
            .graph()
            .nodes()
            .map(|(_, n)| n.id)
            .collect();
        let primary_graph_pane = self.default_graph_pane();
        if let Some(workbench) = self.workbench_for_pane_mut(primary_graph_pane) {
            *workbench = session::load_workbench(&sdir, &present);
        }
        // The history seeds from wherever the session opens (the focused
        // node's url, or an empty sentinel Back can never step past).
        self.history = chrome::nav::History::new(
            self.graph_runtimes
                .focused_url()
                .map(str::to_string)
                .unwrap_or_default(),
        );
        // Restore WHERE the user was (rung 6): re-select the most recently
        // visited node when nothing is selected (restored live content
        // composes for the FOCUSED node), and CENTER the camera on it — the
        // adopted session opens looking at its focus, not at whatever the
        // default origin happens to crop.
        if self.graph_runtimes.focused_member().is_none()
            && let Some(last) = self
                .graph_runtimes
                .graph()
                .recent_visited(1)
                .into_iter()
                .next()
        {
            self.graph_runtimes.select_by_url(&last.url);
        }
        self.graph_runtimes.center_on_selected();
        // Seed the primary graph pane's published context after restore. Its
        // view is first installed lazily, so a restored graph selection is
        // captured into that pane rather than becoming a global follower
        // source.
        let primary_graph_pane = self.default_graph_pane();
        let active_graph = self.graph_runtimes.active_graph();
        if let Some(canvas) = self.graph_runtimes.canvas_mut(active_graph) {
            self.graph_views.install(primary_graph_pane, canvas);
        }
        self.publish_graph_context(primary_graph_pane);
        // Browser state + content-state restore: read from the web.* facets
        // (the converged home); a pre-convergence profile's browser_nodes.json
        // seeds nodes the facets don't know (one-time legacy absorb — the next
        // save writes facets only, and the stale file is left inert). Every
        // node whose content was ON respawns through the ordinary port, so
        // `Live` here is spawned truth, never a painted memory.
        self.browser = pandect::read_web_states(self.graph_runtimes.facets());
        for (id, legacy) in session::load_legacy_browser_nodes(&sdir).nodes {
            self.browser.nodes.entry(id).or_insert(legacy);
        }
        if super::migrate_retired_viewer_overrides(&mut self.browser) {
            effects.push(Effect::SaveSession);
        }
        // The bin mirror empties until the reopened session store answers
        // (the shell re-points the bin actor on switch; BinListed refills).
        self.removed.clear();
        self.content = ContentStates::default();
        self.link_preview = None;
        for (_, node) in self.graph_runtimes.graph().nodes() {
            if self.browser.get(node.id).is_some_and(|b| b.content_on) {
                self.content.note_requested(node.id);
                effects.push(Effect::SpawnContent {
                    node: node.id,
                    url: node.url().to_string(),
                });
            }
        }
        self.window_count = 1;
        let label = self.session_label(id);
        self.events.push(AppEvent::SessionSwitched(label));
        effects.push(Effect::Redraw);
        effects
    }

    /// Refresh the browser-state sidecar from live truth before a save
    /// (rung 6): each graph node's `content_on` mirrors its content
    /// lifecycle (live or in flight), and entries for vanished nodes drop.
    pub fn refresh_browser_states(&mut self) {
        use crate::content::NodeContent;
        let present: std::collections::HashSet<uuid::Uuid> = self
            .graph_runtimes
            .graph()
            .nodes()
            .map(|(_, n)| n.id)
            .collect();
        let stale: Vec<uuid::Uuid> = self
            .browser
            .nodes
            .keys()
            .copied()
            .filter(|id| !present.contains(id))
            .collect();
        for id in stale {
            self.browser.remove(id);
        }
        for id in present {
            let on = matches!(
                self.content.get(id),
                Some(
                    NodeContent::Live
                        | NodeContent::Requested
                        | NodeContent::AwaitingInput
                        | NodeContent::AwaitingIdentity
                        | NodeContent::AwaitingTrust
                )
            );
            if on || self.browser.get(id).is_some() {
                self.browser.entry(id).content_on = on;
            }
        }
    }

    pub(super) fn recover_session(&mut self, id: SessionId) -> Vec<Effect> {
        // Overmap O3 recovery: the trashed directory moves back whole
        // (graph + facets + bin), the manifest re-lists, and the
        // ordinary switch adopts it — same identity by construction.
        match self.sessions.restore_from_trash(id) {
            Ok(true) => {
                self.trash = self.sessions.list_trash();
                self.events
                    .push(AppEvent::SessionRecovered(self.session_label(id)));
                vec![Effect::SwitchSession { id }]
            }
            Ok(false) => {
                tracing::warn!(session = %id.as_uuid(), "no trash entry to recover");
                vec![Effect::Redraw]
            }
            Err(err) => {
                tracing::warn!(%err, "failed to recover the trashed session");
                vec![Effect::Redraw]
            }
        }
    }

    pub(super) fn close_session(&mut self) -> Vec<Effect> {
        // Trash the current session, then land on the newest remaining
        // one; if it was the last, mint a fresh empty session. Either
        // way the switch effect saves nothing for the trashed session
        // (it is already gone) and adopts the target.
        let closing = self.session_id;
        let next = self
            .sessions
            .iter()
            .filter(|(id, _)| *id != closing)
            .max_by_key(|(_, m)| m.updated_at)
            .map(|(id, _)| id)
            .unwrap_or_else(|| Self::mint_session(&self.data_root, &mut self.sessions));
        // The disk half (bin release + trash move + adopt-without-save)
        // is ordering the SHELL owns — see Effect::TrashSession.
        vec![Effect::TrashSession { closing, next }]
    }

    pub(super) fn begin_rename_session(&mut self) -> Vec<Effect> {
        // Seed empty (the omnibar has no selection, so a seeded label
        // could not be replaced by typing); the current label shows in
        // the switcher, and an empty commit clears back to it.
        self.omnibar = OmnibarState {
            open: true,
            mode: crate::ui::OmnibarMode::RenameSession(self.session_id),
            ..OmnibarState::default()
        };
        let target = self.fallback_shell_context();
        self.shell.begin_omnibar(target);
        self.focus = FocusTarget::Chrome;
        self.recompute_omnibar_suggestions();
        self.events.push(AppEvent::OmnibarOpened);
        vec![Effect::Redraw]
    }

    pub(super) fn rename_session(&mut self, id: SessionId, name: String) -> Vec<Effect> {
        let name = name.trim().to_string();
        let applied = self.sessions.update(id, |m| {
            m.display_name = (!name.is_empty()).then(|| name.clone());
        });
        if applied {
            let _ = self.sessions.flush_dirty();
            self.events
                .push(AppEvent::SessionRenamed(self.session_label(id)));
        }
        vec![Effect::Redraw]
    }

    pub(super) fn empty_recycle_bin(&mut self) -> Vec<Effect> {
        // Athanor's oven, on command: the bin actor clears its store
        // and answers with the empty list (which refreshes the mirror).
        // A no-op when the bin is already empty (honest — no event).
        if self.removed.is_empty() {
            return vec![Effect::Redraw];
        }
        self.events
            .push(AppEvent::RecycleBinEmptied(self.removed.len()));
        vec![Effect::EmptyRecycleBin, Effect::Redraw]
    }

    /// Resolve the visible image misses the canvas observed in its last frame.
    /// Content-addressing makes duplicate references one request, and the
    /// canvas's byte-bounded LRU will ask again if an evicted digest later
    /// returns to view.
    pub(crate) fn resolve_pending_images(&mut self) -> usize {
        let refs = self.graph_runtimes.take_image_requests();
        if refs.is_empty() {
            return 0;
        }
        let sdir = self.session_dir();
        let mut loaded = 0;
        for image in refs {
            let Some(bytes) = session::load_image_blob(&sdir, &image.hex()) else {
                continue;
            };
            let Some(decoded) = crate::browse::decode_image_bytes(&bytes) else {
                continue;
            };
            self.graph_runtimes.register_resolved_image(
                image.digest,
                decoded.rgba,
                decoded.width,
                decoded.height,
            );
            loaded += 1;
        }
        loaded
    }
}
