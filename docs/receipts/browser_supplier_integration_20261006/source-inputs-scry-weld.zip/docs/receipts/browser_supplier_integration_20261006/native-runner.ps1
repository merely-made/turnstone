# Helpers for the exact-source native supplier qualification. Does not build.
$ErrorActionPreference = 'Stop'
$receiptRepository = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path

function Observe-SupplierModules {
    param($OwnedProcess, $ObservedPaths, $Limitations)
    try {
        $OwnedProcess.Refresh()
        # Only the process handle created by this runner is inspected.
        foreach ($module in $OwnedProcess.Modules) {
            if ($module.ModuleName -notmatch '^(libEGL|libGLESv2|libcef|WebView2Loader|d3d11|d3d12|D3D12Core|dxgi|dxcompiler|dxil|vulkan-1|vk_swiftshader|opengl32)\.dll$' -and
                $module.ModuleName -notmatch '(wgpu|graft|scry|weld).*\.dll$') { continue }
            $path = $module.FileName
            if ($ObservedPaths.ContainsKey($path)) { continue }
            $entry = [ordered]@{
                module=$module.ModuleName; path=$path; sha256=$null;
                first_observed_utc=[DateTime]::UtcNow.ToString('o'); hash_limitation=$null
            }
            try {
                $entry.sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
            } catch {
                $entry.hash_limitation = $_.Exception.Message
                [void] $Limitations.Add("Observed module could not be hashed: $path; $($_.Exception.Message)")
            }
            # Hashtable keys are case-insensitive. Hash only once per distinct path.
            $ObservedPaths[$path] = $entry
        }
    } catch {
        # Access restrictions or normal process-exit races are observer limits.
        # They cannot establish that an expected module was absent.
        [void] $Limitations.Add("Owned-process module observation unavailable: $($_.Exception.Message)")
    }
}

function Invoke-SupplierReceipt {
    param(
        [Parameter(Mandatory=$true)][string] $Name,
        [Parameter(Mandatory=$true)][string] $Scenario,
        [Parameter(Mandatory=$true)][string] $Profile,
        [Parameter(Mandatory=$true)][string] $Exe,
        [ValidateRange(1,1800)][int] $TimeoutSeconds = 600,
        [switch] $Restart
    )
    $out = Join-Path $PSScriptRoot $Name
    $profilePath = Join-Path $PSScriptRoot "profile/$Profile"
    if (Test-Path -LiteralPath $out) { throw "Receipt already exists: $out" }
    if ($Restart) {
        if (-not (Test-Path -LiteralPath $profilePath -PathType Container)) {
            throw "Restart profile does not exist: $profilePath"
        }
    } elseif (Test-Path -LiteralPath $profilePath) {
        throw "Fresh profile already exists: $profilePath"
    }
    $exePath = (Resolve-Path -LiteralPath $Exe).Path
    $scenarioPath = (Resolve-Path -LiteralPath (Join-Path $receiptRepository $Scenario)).Path
    New-Item -ItemType Directory -Path $out | Out-Null
    $env:TURNSTONE_SCENARIO = $scenarioPath
    $env:TURNSTONE_CAPTURE_DIR = $out
    $env:TURNSTONE_ROOT = $profilePath
    $start = New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName = $exePath
    $start.WorkingDirectory = $receiptRepository
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.StandardOutputEncoding = New-Object System.Text.UTF8Encoding($false)
    $start.StandardErrorEncoding = New-Object System.Text.UTF8Encoding($false)
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $start
    $timedOut = $false
    $nativeExit = $null
    $started = [DateTime]::UtcNow
    try {
        if (-not $process.Start()) { throw "Native process could not start: $Name" }
        $ownedPid = $process.Id
        Write-Host "Running $Name (owned PID $ownedPid)"
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $observedPaths = @{}
        $observerLimitations = New-Object 'System.Collections.Generic.HashSet[string]'
        $snapshotCount = 0
        $deadlineClock = [System.Diagnostics.Stopwatch]::StartNew()
        $exited = $false
        while ($deadlineClock.ElapsedMilliseconds -lt ($TimeoutSeconds * 1000)) {
            Observe-SupplierModules $process $observedPaths $observerLimitations
            $snapshotCount++
            $remaining = ($TimeoutSeconds * 1000) - $deadlineClock.ElapsedMilliseconds
            if ($remaining -le 0) { break }
            $waitMilliseconds = [int] [Math]::Min(250, $remaining)
            if ($process.WaitForExit($waitMilliseconds)) { $exited = $true; break }
        }
        $deadlineClock.Stop()
        if (-not $exited -and $process.HasExited) { $exited = $true }
        if (-not $exited) {
            $timedOut = $true
            # This handle identifies only the application this invocation created.
            # Never terminate by executable name or kill an unrelated process tree.
            if (-not $process.HasExited) { $process.Kill() }
            if (-not $process.WaitForExit(5000)) {
                throw "Owned native PID $ownedPid did not exit after timeout termination"
            }
        }
        $nativeExit = $process.ExitCode
        $utf8 = New-Object System.Text.UTF8Encoding($false)
        $moduleEvidence = [ordered]@{
            owned_pid=$ownedPid; sampling_wait_milliseconds=250; snapshots_attempted=$snapshotCount;
            observed_modules=@($observedPaths.Values | Sort-Object path);
            observer_limitations=@($observerLimitations | Sort-Object);
            scope='Read-only observations of this owned application process only; child processes are not inspected';
            inference_limit='A module not observed during periodic sampling is not proven absent; no staging-path inference'
        }
        [System.IO.File]::WriteAllText((Join-Path $out 'loaded-modules.json'),
            ($moduleEvidence | ConvertTo-Json -Depth 6), $utf8)
        if (-not $stdoutTask.Wait(5000) -or -not $stderrTask.Wait(5000)) {
            throw "Owned PID $ownedPid exited but redirected streams did not close within the bounded drain"
        }
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        [System.IO.File]::WriteAllText((Join-Path $out 'run.stdout.log'), $stdout, $utf8)
        [System.IO.File]::WriteAllText((Join-Path $out 'run.stderr.log'), $stderr, $utf8)
        # Separate streams preserve their own order; this combined file is for reading.
        [System.IO.File]::WriteAllText((Join-Path $out 'run.log'),
            "=== stdout ===`n$stdout`n=== stderr ===`n$stderr", $utf8)
        $record = [ordered]@{
            executable=$exePath; scenario=$scenarioPath; profile=$profilePath;
            owned_pid=$ownedPid; started_utc=$started.ToString('o');
            finished_utc=[DateTime]::UtcNow.ToString('o');
            timeout_seconds=$TimeoutSeconds; timed_out=$timedOut; native_exit=$nativeExit;
            module_evidence='loaded-modules.json';
            scenario_result=$null; environment=[ordered]@{
                RUST_LOG=$env:RUST_LOG; SCRY_FIXTURE_BASE=$env:SCRY_FIXTURE_BASE;
                SERVO_FIXTURE_BASE=$env:SERVO_FIXTURE_BASE; TURNSTONE_CEF_PATH=$env:TURNSTONE_CEF_PATH;
                TURNSTONE_SERVO_PROFILE=$env:TURNSTONE_SERVO_PROFILE;
                TURNSTONE_SERVO_PROFILE_DIR=$env:TURNSTONE_SERVO_PROFILE_DIR
            }
        }
        if (-not $timedOut -and $nativeExit -eq 0) {
            $done = Join-Path $out 'scenario.done'
            if (Test-Path -LiteralPath $done) {
                $record.scenario_result = Get-Content -LiteralPath $done -Encoding UTF8 -First 1
            }
        }
        [System.IO.File]::WriteAllText((Join-Path $out 'process-result.json'),
            ($record | ConvertTo-Json -Depth 4), $utf8)
        if ($timedOut) { throw "Native process exceeded ${TimeoutSeconds}s deadline: $Name" }
        if ($nativeExit -ne 0) { throw "Native process failed ($nativeExit): $Name" }
        if ($record.scenario_result -ne 'RESULT ok') { throw "Scenario failed or missing RESULT ok: $Name" }
        Write-Host "${Name}: $($record.scenario_result); native exit $nativeExit"
    } finally {
        $process.Dispose()
    }
}
